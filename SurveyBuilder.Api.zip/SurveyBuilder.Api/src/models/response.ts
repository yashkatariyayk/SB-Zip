export class CommonResponse {
    StatusCode: number;
    Status: string;
    Message: string;
    Data: any;
    Token: string;
}