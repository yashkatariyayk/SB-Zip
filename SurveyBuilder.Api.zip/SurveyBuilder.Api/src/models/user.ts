export class User {
    Email: string;
    FirstName: string;
    LastName: string;
    Password: string;
    UserId: number;
}