export class Language {
    LanguageId: number;
    Name: string;
    Orientation:string;
    CodeName: string;
    CreatedOn: string;
    CreatedBy: string;
    IsActive: boolean;
    IsDeleted: boolean;
}