export class StaticContent {
  StaticContentId: number;
  Code: string;
  Name: string;
  Value: string;
}
