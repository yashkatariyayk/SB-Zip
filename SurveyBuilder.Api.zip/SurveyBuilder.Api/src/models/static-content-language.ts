export class StaticContentLanguage {
  StaticContentLanguageId: number;
  StaticContentId: number;
  SurveyId: number;
  LanguageId: number;
  Value: string;
}
