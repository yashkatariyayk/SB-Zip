export class SurveySelecteeLanguage {
  SurveySelecteeLanguageId: number;
  SurveySelecteeId: number;
  FirstName: string;
  LastName: string;
  Email: string;
  Role: string;
  Department: string;
  Miscellaneous: string;
  LanguageId: number;
}
