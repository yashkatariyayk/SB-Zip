export class ImportSelectee {
    Id: number;
    SurveyId: number;
    LastImportedDate: string;
}