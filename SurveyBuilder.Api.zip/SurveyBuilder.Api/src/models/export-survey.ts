export class ExportSurvey {
  SelectorId: number;
  SelectorEmail: string;
  QuestionId: number;
  QuestionText: string;
  QuestionType: string;
  MatrixQuestionId: number;
  MatrixQuestionText: string;
  SelecteeId: number;
  SelecteeEmail: string;
  Response: string;
}
