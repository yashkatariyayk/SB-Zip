export class SurveyPageLanguage {
  SurveyPageLanguageId: number;
  SurveyPageId: number;
  SurveyId: number;
  Name: string;
  Description: string;
  LanguageId: number;
}
