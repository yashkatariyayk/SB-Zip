
export class SurveyQuestionScaleType {
    SurveyQuestionScaleTypeId: number;
    Name: string;
    SortOrder: number;
}