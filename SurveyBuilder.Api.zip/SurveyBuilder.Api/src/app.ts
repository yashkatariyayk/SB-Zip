import * as express from "express";
import * as path from "path";
import * as fs from "fs";
import * as bodyParser from "body-parser";
import "reflect-metadata";
import { createConnection } from "typeorm";
import * as appConfig from "./common/db-config";
import * as multer from "multer";
var cors = require("cors");
const UPLOAD_PATH = "uploads";
/**
 * Controllers (route handlers).
 */
import * as authController from "./controllers/auth-controller";
import * as surveyController from "./controllers/survey-controller";
import * as surveyPageController from "./controllers/survey-page-controller";
import * as surveyQuestionController from "./controllers/survey-question-controller";
import * as questionScaleTypeController from "./controllers/survey-question-scale-type-controller";
import * as surveySelecteeController from "./controllers/survey-selectee-controller";
import * as surveySelectorController from "./controllers/survey-selector-controller";
import * as languageController from "./controllers/language-controller";
import * as clientController from "./controllers/client-controller";
import * as emailtemplateController from "./controllers/email-template.controller";
import * as matrixtypeController from "./controllers/matrix-type-controller";
import { EmailTemplateRepo } from "./repositories/email-template-repository";
import * as surveyLanguageController from "./controllers/survey-language-controller";
import { ConfigRepo } from "./repositories/config-repository";

/**
 * Create Express server.
 */
const app = express();
app.use("/static", express.static("./uploads"));
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
app.use(cors());
const v8 = require("v8");
const totalHeapSize = v8.getHeapStatistics().total_available_size;
const totalHeapSizeGb = (totalHeapSize / 1024 / 1024 / 1024).toFixed(2);
console.log("totalHeapSizeGb: ", totalHeapSizeGb);
app.use(function(req, res, next) {
  // Website you wish to allow to connect
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );
  res.header(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, PATCH, OPTIONS"
  );
  next();
});
/**
 * Express configuration.
 */
app.set("port", process.env.PORT || 3000);

/**
 * Start Express server.
 */
app.listen(app.get("port"), () => {
  console.log(
    "  App is running at http://localhost:%d in %s mode",
    app.get("port"),
    app.get("env")
  );
  console.log("  Press CTRL-C to stop\n");
});

var Storage = multer.diskStorage({
  destination: function(req, file, callback) {
    fs.exists("./uploads", function(exists) {
      if (exists) {
        callback(null, "uploads");
      } else {
        fs.mkdir("./uploads", function(err) {
          if (err) {
            console.log("Error in folder creation");
          }
          callback(null, "uploads");
        });
      }
    });
  },
  filename: function(req, file, callback) {
    file.filename = file.fieldname + "_" + Date.now() + "_" + file.originalname;
    callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
  }
});

var upload = multer({
  storage: Storage
});

// setInterval(function() {
//   console.log(
//     "#################### Email schedular get called ####################"
//   );
//   let emailTemplateRepo: EmailTemplateRepo = new EmailTemplateRepo();
//   emailTemplateRepo.runEmailSchedular().then((result: any) => {
//     //  console.log('result',result);
//   });
// }, 15000);

const router = express.Router();
/**
 * Primary app routes.
 */
app.post("/api/auth/token", authController.getToken);

/* Add, edit, delete survey*/
app.post("/api/copy/survey", surveyController.copySurvey);
app.post("/api/survey", surveyController.createSurvey);
app.get("/api/survey", surveyController.getSurvey);
app.post("/api/all/survey", surveyController.getAllSurvey);
app.delete("/api/survey", surveyController.deleteSurvey);
app.put("/api/survey", upload.single("Logo"), surveyController.updateSurvey);

/* get survey status*/
app.get("/api/survey/status", surveyController.getSurveyStatus);

/* save survey page*/
app.post("/api/survey/page", surveyPageController.saveSurveyPage);
app.get("/api/survey/page", surveyPageController.getSurveyPage);
app.put("/api/survey/page", surveyPageController.updateSurveyPage);
app.delete("/api/survey/page", surveyPageController.deleteSurveyPage);

/* save survey question*/
app.post("/api/survey/question", surveyQuestionController.saveSurveyQuestion);
app.get("/api/survey/question", surveyQuestionController.getSurveyQuestion);
app.put("/api/survey/question", surveyQuestionController.updateSurveyQuestion);
app.delete(
  "/api/survey/question",
  surveyQuestionController.deleteSurveyQuestion
);
app.delete(
  "/api/survey/question/option",
  surveyQuestionController.deleteOption
);

/* get scale type*/
app.get(
  "/api/survey/question/scaleType",
  questionScaleTypeController.getQuestionScaleType
);
app.get(
  "/api/survey/question/scaleBank",
  questionScaleTypeController.getQuestionScaleBank
);

/* import selectees */
app.post("/api/survey/selectee", surveySelecteeController.saveSurveySelectee);
app.post(
  "/api/survey/selectee/:surveyId",
  surveySelecteeController.getSurveySelectee
);
app.put("/api/survey/selectee", surveySelecteeController.updateSurveySelectee);
app.delete(
  "/api/survey/selectee",
  surveySelecteeController.deleteSurveySelectee
);
app.post(
  "/api/survey/selectee/delete/many",
  surveySelecteeController.deleteMultipleSurveySelectee
);

/* import selectors*/
app.post("/api/survey/selector", surveySelectorController.saveSurveySelector);
app.post(
  "/api/survey/selector/:surveyId",
  surveySelectorController.getSurveySelector
);
// app.get("/api/survey/selector", surveySelectorController.getSurveySelector);
app.put("/api/survey/selector", surveySelectorController.updateSurveySelector);
app.delete(
  "/api/survey/selector",
  surveySelectorController.deleteSurveySelector
);
app.post(
  "/api/survey/selector/delete/many",
  surveySelectorController.deleteMultipleSurveySelector
);

/* get survey status*/
app.post("/api/language", languageController.saveLanguage);
app.get("/api/language", languageController.getLanguage);
app.delete("/api/language", languageController.deleteLanguage);

/**get client list */
app.get("/api/client", clientController.getClient);

/* get email template list */
app.get("/api/emailTemplate", emailtemplateController.getEmailTemplate);
app.get(
  "/api/emailTemplate/:id/:languageId",
  emailtemplateController.getEmailTemplateById
);
app.post("/api/emailTemplate/sendEmail", emailtemplateController.sendEmail);
app.post("/api/email", emailtemplateController.saveEmailLog);
app.get("/api/email/config/:isAll", emailtemplateController.getEmailConfig);
app.put("/api/email/config/:id", emailtemplateController.updateEmailConfig);

/* get matrix-type list */
app.get("/api/matrixType", matrixtypeController.getMatrixType);

/* get survey response */
app.get("/api/survey/response/:id", surveyController.getSurveyResponse);
app.delete("/api/survey/response/:surveyId", surveyController.clearResponse);

/* get survey static content */
app.get("/api/survey/static", surveyController.getSurveyStaticContent);
app.post("/api/survey/static", surveyController.saveSurveyStaticContent);

/* save survey static content in multi language */
app.post(
  "/api/survey/static/language",
  surveyLanguageController.saveStaticContentMultiLanguage
);

/* save survey selectee in multi language */
app.post(
  "/api/selectee/language",
  surveyLanguageController.saveSelecteeMultiLanguage
);

/* save email templates in multi language */
app.post(
  "/api/survey/emailTemplate/language",
  surveyLanguageController.saveEmailTemplateMultiLanguage
);

/* save survey in multi language */
app.post(
  "/api/survey/language",
  surveyLanguageController.saveSurveyMultiLanguage
);

/**
 * Create connection to DB using configuration provided in
 * appconfig file.
 */
createConnection(appConfig.dbOptions)
  .then(async (connection) => {
    console.log("Connected to DB");
  })
  .catch((error) => console.log("TypeORM connection error: ", error));

module.exports = app;
