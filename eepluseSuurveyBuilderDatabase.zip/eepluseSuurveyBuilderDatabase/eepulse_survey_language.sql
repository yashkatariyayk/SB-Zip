-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: TA33    Database: eepulse_survey_shraddha
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `language` (
  `LanguageId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `CodeName` varchar(255) NOT NULL,
  `CreatedOn` varchar(255) NOT NULL,
  `CreatedBy` varchar(255) NOT NULL,
  `IsDeleted` tinyint(25) NOT NULL DEFAULT '0',
  `IsActive` tinyint(25) NOT NULL DEFAULT '1',
  PRIMARY KEY (`LanguageId`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` VALUES (1,'English','en','12/13/2019','Admin',1,1),(2,'Hindi','hn','12/13/2019','Admin',1,1),(3,'Spanish','sp','12/13/2019','Admin',1,1),(4,'French','fr','12/13/2019','Admin',1,1),(5,'Hindi','Hi','Mon Jul 08 2019 17:53:26 GMT+0530 (India Standard Time)','Admin',1,1),(6,'Gujrati','Gu','Mon Jul 08 2019 19:17:09 GMT+0530 (India Standard Time)','Admin',1,1),(7,'demo','de','Mon Jul 08 2019 19:17:23 GMT+0530 (India Standard Time)','Admin',1,1),(8,'Franch','Fr','Mon Jul 08 2019 19:24:49 GMT+0530 (India Standard Time)','Admin',1,1),(9,'English','En','Mon Jul 08 2019 19:28:53 GMT+0530 (India Standard Time)','Admin',1,1),(10,'English','En','Mon Jul 08 2019 19:33:28 GMT+0530 (India Standard Time)','Admin',1,1),(11,'Franch','Fr','Mon Jul 08 2019 19:33:33 GMT+0530 (India Standard Time)','Admin',1,1),(12,'English','En','Mon Jul 08 2019 19:36:22 GMT+0530 (India Standard Time)','Admin',0,1),(13,'Franch','Fr','Mon Jul 08 2019 19:59:54 GMT+0530 (India Standard Time)','Admin',1,1),(14,'Franch','Fr','Tue Jul 09 2019 11:58:48 GMT+0530 (India Standard Time)','Admin',1,1),(15,'Hindi','Hi','Tue Jul 09 2019 11:59:01 GMT+0530 (India Standard Time)','Admin',1,1),(16,'Hindi','Hi','Mon Jul 15 2019 14:51:05 GMT+0530 (India Standard Time)','Admin',1,1),(17,'Spanish','Sp','Thu Jul 18 2019 15:48:27 GMT-0400 (Eastern Daylight Time)','Justin',0,1),(18,'French','Fr','Thu Jul 18 2019 15:48:40 GMT-0400 (Eastern Daylight Time)','Justin',0,1);
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-24 11:16:06
