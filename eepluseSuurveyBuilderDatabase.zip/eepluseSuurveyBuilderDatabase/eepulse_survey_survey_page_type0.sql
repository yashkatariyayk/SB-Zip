-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: TA33    Database: eepulse_survey
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_page_type`
--

DROP TABLE IF EXISTS `survey_page_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `survey_page_type` (
  `SurveyPageTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `Description` varchar(3000) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SurveyPageTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_page_type`
--

LOCK TABLES `survey_page_type` WRITE;
/*!40000 ALTER TABLE `survey_page_type` DISABLE KEYS */;
INSERT INTO `survey_page_type` VALUES (1,'Welcome Page','<h4>Welcome to the Survey.</h4>\n\n<p>Your views, thoughts and experiences are vital to our development as a company.Please share what you think about the company and how it feels to work here by taking part in this confidential survey.<br />\n<br />\nThis survey will take approximately 10 minutes to complete.To complete the survey in more than one session, simply click the &ldquo;Continue&rdquo; button when you&rsquo;re ready to stop, and your current responses will be saved. You may return to the survey before the close date to complete and submit your survey.<br />\n<br />\nThank you for joining in.</p>\n',''),(2,'Your survey responses have been successfully submitted.','<p><strong>Thank you for giving your time to complete this survey. Your views are very important to us.</strong></p>',''),(3,'Survey already submitted','<p>The survey has already been submitted with this survey link.</p>','');
/*!40000 ALTER TABLE `survey_page_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-30 13:46:19
