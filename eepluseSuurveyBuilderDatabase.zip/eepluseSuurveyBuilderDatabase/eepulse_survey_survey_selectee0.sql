-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: TA33    Database: eepulse_survey
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey_selectee`
--

DROP TABLE IF EXISTS `survey_selectee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `survey_selectee` (
  `SurveySelecteeId` int(11) NOT NULL AUTO_INCREMENT,
  `SurveyId` int(25) NOT NULL,
  `EmployeeId` int(25) DEFAULT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Role` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `CompanyId` varchar(255) DEFAULT NULL,
  `IsDeleted` tinyint(255) NOT NULL DEFAULT '0',
  `Miscellaneous` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`SurveySelecteeId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_selectee`
--

LOCK TABLES `survey_selectee` WRITE;
/*!40000 ALTER TABLE `survey_selectee` DISABLE KEYS */;
INSERT INTO `survey_selectee` VALUES (1,1,1,'Kelly','Welbourne','kelly@eepulse.com','CEO','Management',NULL,0,'0'),(2,1,2,'Justin','Glenn','justin@eepulse.com','CEO','Management',NULL,1,'0'),(3,2,1,'Shraddha','Prajapati','shraddha123@gmail.com','Manager','Human Resource',NULL,1,'abc\r'),(4,2,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(5,2,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(6,3,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(7,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(8,139,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,0,'abc\r'),(9,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(10,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(11,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(12,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(13,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,1,'abc\r'),(14,115,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,0,'abc\r'),(15,4,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,0,'abc\r'),(16,153,1,'Nidhi','Dungarani','nidhi.dungarani@techavidus.com','Manager','Human Resource',NULL,0,'abc\r');
/*!40000 ALTER TABLE `survey_selectee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-30 13:46:22
