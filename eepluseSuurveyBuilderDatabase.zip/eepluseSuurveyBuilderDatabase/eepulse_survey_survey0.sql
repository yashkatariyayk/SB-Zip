-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: TA33    Database: eepulse_survey
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `survey` (
  `SurveyId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `StartDate` datetime DEFAULT NULL,
  `EndDate` datetime DEFAULT NULL,
  `IsDeleted` tinyint(25) NOT NULL DEFAULT '0',
  `CreatedBy` varchar(255) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `ThemeId` int(25) DEFAULT NULL,
  `SurveyStatusId` int(25) DEFAULT NULL,
  `ClientId` int(25) DEFAULT NULL,
  `IsTemplate` tinyint(25) NOT NULL DEFAULT '0',
  `LogoName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SurveyId`),
  KEY `fk_e844987342606f72c7feb9251d1` (`ThemeId`),
  KEY `fk_0aa230a265e62aed71cea6bc65b` (`SurveyStatusId`),
  KEY `fk_5892c03bbead88d7f4922b66309` (`ClientId`),
  CONSTRAINT `fk_0aa230a265e62aed71cea6bc65b` FOREIGN KEY (`SurveyStatusId`) REFERENCES `survey_status` (`surveystatusid`),
  CONSTRAINT `fk_5892c03bbead88d7f4922b66309` FOREIGN KEY (`ClientId`) REFERENCES `client` (`clientid`),
  CONSTRAINT `fk_e844987342606f72c7feb9251d1` FOREIGN KEY (`ThemeId`) REFERENCES `survey_theme` (`surveythemeid`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (2,'Employee Engagement Survey','2019-07-11 00:00:00','2019-07-15 00:00:00',0,'Admin','2019-06-28 12:25:26',1,1,1,0,'Logo_1564142440424_login_screen.png'),(3,'Employee Satisfaction','2019-07-17 12:40:48','2019-07-17 12:40:48',0,'Admin','2019-06-28 12:39:53',1,2,1,0,'Logo_1563260523092_download (2).jpg'),(4,'New Joinee','2019-07-08 19:35:45','2019-07-08 19:35:45',0,'Admin','2019-06-28 12:40:36',1,3,1,0,'Logo_1563195163080_download.jpg'),(70,'BT Onboarding Survey','2019-07-01 18:30:00','2019-07-17 18:30:00',0,'Admin','2019-07-16 10:48:02',1,2,1,0,NULL),(115,'Justin Test','2019-07-18 06:35:06','2019-07-18 06:35:06',0,'Admin','2019-07-18 19:21:55',1,3,1,0,NULL),(147,'Copy Of - New Joinee',NULL,NULL,0,'Admin','2019-07-22 12:24:10',1,3,1,0,NULL),(150,'Test Survey',NULL,NULL,0,'Admin','2019-07-23 07:02:42',1,3,1,0,NULL),(151,'Survey with Client Test',NULL,NULL,0,'Admin','2019-07-23 11:07:58',1,3,1,0,NULL),(153,'Demo Survey',NULL,NULL,0,'Admin','2019-07-24 08:28:02',1,3,1,0,'Logo_1563972003426_download (2).jpg'),(154,'New Joinee',NULL,NULL,0,'Admin','2019-07-26 11:56:18',1,3,NULL,0,NULL),(155,'Copy Of - Employee Engagement Survey',NULL,NULL,0,'Admin','2019-07-26 11:56:18',1,3,NULL,0,NULL),(156,'New Joinee',NULL,NULL,0,'Admin','2019-07-26 12:00:40',1,3,NULL,0,NULL),(157,'Copy Of - Employee Engagement Survey',NULL,NULL,0,'Admin','2019-07-26 12:00:40',1,3,NULL,0,NULL);
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-30 13:46:26
