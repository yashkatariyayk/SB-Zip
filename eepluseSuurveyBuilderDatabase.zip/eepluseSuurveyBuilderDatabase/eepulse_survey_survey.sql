-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: TA33    Database: eepulse_survey_shraddha
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `survey` (
  `SurveyId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `StartDate` datetime DEFAULT NULL,
  `EndDate` datetime DEFAULT NULL,
  `IsDeleted` tinyint(25) NOT NULL DEFAULT '0',
  `CreatedBy` varchar(255) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `ThemeId` int(25) DEFAULT NULL,
  `SurveyStatusId` int(25) DEFAULT NULL,
  `ClientId` int(25) DEFAULT NULL,
  `IsTemplate` tinyint(25) NOT NULL DEFAULT '0',
  `LogoName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SurveyId`),
  KEY `fk_e844987342606f72c7feb9251d1` (`ThemeId`),
  KEY `fk_0aa230a265e62aed71cea6bc65b` (`SurveyStatusId`),
  KEY `fk_5892c03bbead88d7f4922b66309` (`ClientId`),
  CONSTRAINT `fk_0aa230a265e62aed71cea6bc65b` FOREIGN KEY (`SurveyStatusId`) REFERENCES `survey_status` (`surveystatusid`),
  CONSTRAINT `fk_5892c03bbead88d7f4922b66309` FOREIGN KEY (`ClientId`) REFERENCES `client` (`clientid`),
  CONSTRAINT `fk_e844987342606f72c7feb9251d1` FOREIGN KEY (`ThemeId`) REFERENCES `survey_theme` (`surveythemeid`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (2,'Employee Engagement Survey','2019-07-11 00:00:00','2019-07-15 00:00:00',0,'Admin','2019-06-28 12:25:26',1,1,1,0,'Logo_1563260213863_download_1.jpg'),(3,'Employee Satisfaction','2019-07-17 12:40:48','2019-07-17 12:40:48',0,'Admin','2019-06-28 12:39:53',1,2,1,0,'Logo_1563260523092_download (2).jpg'),(4,'New Joinee','2019-07-08 19:35:45','2019-07-08 19:35:45',0,'Admin','2019-06-28 12:40:36',1,3,1,0,'Logo_1563195163080_download.jpg'),(44,'Pulse Survey','2019-07-10 15:33:31','2019-07-10 15:33:31',1,'Admin','2019-07-09 14:04:02',1,3,1,0,'Logo_1563191998411_download (2).png'),(45,'Demo',NULL,NULL,1,'Admin','2019-07-11 12:23:49',1,3,1,0,NULL),(70,'BT Onboarding Survey','2019-07-01 18:30:00','2019-07-17 18:30:00',0,'Admin','2019-07-16 10:48:02',1,3,1,0,NULL),(107,'Demo 1',NULL,NULL,1,'Admin','2019-07-18 06:33:25',1,3,1,0,NULL),(108,'Copy Of - New Joinee',NULL,NULL,1,'Admin','2019-07-18 06:33:38',1,3,1,0,NULL),(111,'My new survey',NULL,NULL,1,'Admin','2019-07-18 06:57:39',1,3,1,0,NULL),(112,'Demo Survey',NULL,NULL,1,'Admin','2019-07-18 07:06:34',1,3,1,0,NULL),(113,'Demo Survey','1970-01-01 05:30:00','1970-01-01 05:30:00',1,'Admin','2019-07-18 08:09:57',1,3,1,0,'Logo_1563437423987_download (3).jpg'),(114,'Test Validation',NULL,NULL,1,'Admin','2019-07-18 08:12:50',1,3,1,0,'Logo_1563440260376_download.png'),(115,'Justin Test','2019-07-18 06:35:06','2019-07-18 06:35:06',0,'Admin','2019-07-18 19:21:55',1,4,1,0,NULL),(116,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 09:51:20',1,3,1,0,NULL),(117,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 09:52:51',1,3,1,0,NULL),(118,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 09:54:51',1,3,1,0,NULL),(119,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 09:58:20',1,3,1,0,NULL),(120,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 09:59:32',1,3,1,0,NULL),(121,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:00:49',1,3,1,0,NULL),(122,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:30:22',1,3,1,0,NULL),(123,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 10:30:51',1,3,1,0,NULL),(124,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 10:39:40',1,3,1,0,NULL),(125,'Copy Of - Employee Satisfaction',NULL,NULL,1,'Admin','2019-07-19 10:39:50',1,3,1,0,NULL),(126,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:39:56',1,3,1,0,NULL),(127,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:40:07',1,3,1,0,NULL),(128,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 10:40:14',1,3,1,0,NULL),(129,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 10:53:00',1,3,1,0,NULL),(130,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:53:16',1,3,1,0,NULL),(131,'Copy Of - New Joinee',NULL,NULL,1,'Admin','2019-07-19 10:53:39',1,3,1,0,NULL),(132,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 10:55:55',1,3,1,0,NULL),(133,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 10:56:09',1,3,1,0,NULL),(134,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 11:03:11',1,3,1,0,NULL),(135,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 11:05:11',1,3,1,0,NULL),(136,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 11:10:02',1,3,1,0,NULL),(137,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-19 11:10:13',1,3,1,0,NULL),(138,'Copy Of - Employee Engagement Survey',NULL,NULL,1,'Admin','2019-07-19 11:10:23',1,3,1,0,NULL),(139,'Copy Of - Justin Test',NULL,NULL,1,'Admin','2019-07-22 06:10:10',1,3,1,0,NULL),(140,'Copy Of - Test Validation',NULL,NULL,1,'Admin','2019-07-22 06:11:14',1,3,1,0,NULL),(141,'Copy Of - Demo Survey',NULL,NULL,1,'Admin','2019-07-22 06:12:25',1,3,1,0,NULL),(142,'Copy Of - New Joinee',NULL,NULL,1,'Admin','2019-07-22 07:13:50',1,3,1,0,NULL),(143,'Test Survey',NULL,NULL,0,'Admin','2019-07-22 11:21:32',1,3,1,0,NULL),(144,'Demo Survey',NULL,NULL,1,'Admin','2019-07-22 11:31:57',1,3,1,0,NULL),(145,'Demo Survey','2019-07-15 18:30:00','2019-07-25 18:30:00',0,'Admin','2019-07-22 11:38:22',1,3,1,0,NULL),(146,'fgfgfdg',NULL,NULL,1,'Admin','2019-07-22 11:56:27',1,3,1,0,NULL),(147,'Copy Of - New Joinee',NULL,NULL,0,'Admin','2019-07-22 12:24:10',1,3,1,0,NULL),(148,'Test Survey',NULL,NULL,1,'Admin','2019-07-23 07:00:32',1,3,1,0,NULL),(149,'test 2 survey',NULL,NULL,1,'Admin','2019-07-23 07:01:29',1,3,1,0,NULL),(150,'Test Survey',NULL,NULL,0,'Admin','2019-07-23 07:02:42',1,3,1,0,NULL),(151,'Survey with Client Test',NULL,NULL,0,'Admin','2019-07-23 11:07:58',1,3,1,0,NULL),(152,'Test Code Check',NULL,NULL,0,'Admin','2019-07-24 05:27:44',1,3,1,0,NULL);
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-24 11:16:08
