// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `angular-cli.json`.

// For Local : Start
export const environment = {
  production: false,
  RootUrl: "http://localhost:4200/",
  SurveyUrl: "http://203.192.235.219:9090/EEPulseSurvey/Web/",
  APIURL: "http://localhost:3000/api",
  IMAGEURL: "http://localhost:3000/static/",
  whitelistedDomains: ["localhost:3000", "localhost:4200"],
  blacklistedRoutes: []
};
// For Local : Start
