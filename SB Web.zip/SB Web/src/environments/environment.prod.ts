// ng build --prod --base-href /EEPulseSurveyBuilder/Web/
export const environment = {
  production: false,
  RootUrl: "http://18.191.247.188/EEPulseSurveyBuilder/Web/",
  SurveyUrl: "http://18.191.247.188/EEPulseSurvey/Web/",
  APIURL: "http://18.191.247.188/EEPulseSurveyBuilder/Api/api",
  IMAGEURL: "http://18.191.247.188/EEPulseSurveyBuilder/Api/static/",
  whitelistedDomains: ["18.191.247.188", "ta33"],
  blacklistedRoutes: []
};
