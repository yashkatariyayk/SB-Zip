import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { FormControl, Validators } from "@angular/forms";
import { CreateSurveyService } from "./create-survey.service";
import { CommonService } from "src/app/core/services/common.service";
import { Survey, Client } from "../survey/survey-list/survey-list.model";
import { UtilityComponent } from "src/app/core/services/utility";

@Component({
  selector: "app-create-survey",
  templateUrl: "./create-survey.component.html",
  styleUrls: ["./create-survey.component.scss"]
})
export class CreateSurveyComponent implements OnInit {
  nameFormControl = new FormControl("", [Validators.required]);
  constructor(
    private router: Router,
    private createSurveyService: CreateSurveyService,
    private commonService: CommonService
  ) {}

  public surveyName: string;
  public loader: boolean;
  public clientList: Client[] = [];
  public clientId: number;

  ngOnInit() {
    this.surveyName = "";
    this.getClientList();
  }

  getClientList() {
    this.createSurveyService.getClientList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.clientList = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  saveSurvey() {
    this.loader = true;
    if (this.surveyName.trim() === "") {
      this.loader = false;
      return false;
    }
    let obj = new Survey();
    obj.Name = this.surveyName.trim();
    obj.ClientId = this.clientId;
    let todatDate = new Date();
    obj.CreatedOn = UtilityComponent.getUTCDate(todatDate);
    this.createSurveyService
      .createSurvey("/survey", obj)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.loader = false;
          this.commonService.toaster("Survey created successfully.", true);
          this.router.navigate(["/survey/survey-detail/", res.Data.SurveyId]);
        } else {
          this.loader = false;
          this.commonService.toaster(res.Message, false);
        }
      });
  }
}
