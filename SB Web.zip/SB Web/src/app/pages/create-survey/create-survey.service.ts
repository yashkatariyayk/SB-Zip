import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClientService } from "src/app/core/services/http-client.service";
@Injectable()
export class CreateSurveyService {
  baseURL: string = environment.APIURL;

  constructor(private httpClient: HttpClientService) {}

  getClientList() {
    let url = "/client";
    return this.httpClient.get(url);
  }

  createSurvey(url, obj: any) {
    return this.httpClient.post(url, obj);
  }
}
