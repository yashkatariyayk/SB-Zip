import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule } from '@angular/forms';
import { ToasterModule } from 'angular2-toaster';
import {MatRadioModule} from '@angular/material/radio';
import { PreviewSurveyComponent } from './preview-survey.component';
import { SurveyDetailService } from '../survey/survey-detail/survey-detail.service';
const routes: Routes = [
    { path: '', component: PreviewSurveyComponent }
];

@NgModule({
    declarations: [
        PreviewSurveyComponent
    ],
    imports: [
        FormsModule,
        SharedModule,
        ToasterModule,
        MatRadioModule,
        RouterModule.forChild(routes),
    ],
    providers: [
        SurveyDetailService
       // LoginService
    ],
    exports: [RouterModule]
})
export class PreviewSurveyModule { }
