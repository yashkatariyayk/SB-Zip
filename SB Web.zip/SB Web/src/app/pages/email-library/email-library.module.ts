import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailLibraryComponent } from './email-library.component';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: EmailLibraryComponent,
    data: {
      title: 'Email Library',
      breadcrumb: [
        {
          label: 'Email Library',
          url: ''
        }
      ]
    }
  }
];

@NgModule({
  declarations: [EmailLibraryComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class EmailLibraryModule { }
