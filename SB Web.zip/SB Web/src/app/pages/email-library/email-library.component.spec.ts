import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailLibraryComponent } from './email-library.component';

describe('EmailLibraryComponent', () => {
  let component: EmailLibraryComponent;
  let fixture: ComponentFixture<EmailLibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailLibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
