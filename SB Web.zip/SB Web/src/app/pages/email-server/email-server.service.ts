import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClientService } from "src/app/core/services/http-client.service";
@Injectable()
export class EmailServerService {
  baseURL: string = environment.APIURL;

  constructor(private httpClient: HttpClientService) {}

  get() {
    let url = "/email/config/" + 1;
    return this.httpClient.get(url);
  }

  update(id: number) {
    return this.httpClient.put("/email/config/" + id, {});
  }
}
