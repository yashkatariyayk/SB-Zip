import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LanguageComponent } from './language.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { Routes, RouterModule } from '@angular/router';
import { LanguageService } from './language.service';
import { AddEditLanguageComponent } from './add-edit-language/add-edit-language.component';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { LaddaModule } from 'angular2-ladda';

const routes: Routes = [
  {
    path: '',
    component: LanguageComponent,
    data: {
      title: 'Language',
      breadcrumb: [
        {
          label: 'Language',
          url: ''
        }
      ]
    }
  }
];
@NgModule({
  declarations: [LanguageComponent, AddEditLanguageComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    LaddaModule
  ],
  exports: [
    AddEditLanguageComponent
  ],
  providers: [
    LanguageService
],
entryComponents: [
  AddEditLanguageComponent

]
})
export class LanguageModule { }
