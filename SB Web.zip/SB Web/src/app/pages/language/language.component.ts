import { Component, OnInit } from '@angular/core';
import { Language } from './language';
import { LanguageService } from './language.service';
import { CommonService } from 'src/app/core/services/common.service';
import { MatDialog } from '@angular/material';
import { AddEditLanguageComponent } from './add-edit-language/add-edit-language.component';
import { ConfirmDialogComponent } from 'src/app/shared/components/confirm-dialog/confirm-dialog.component';


@Component({
  selector: 'app-language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.scss']
})
export class LanguageComponent implements OnInit {
 //  public displayedColumns: string[] = ['select', 'Language', 'actions'];
  public displayedColumns: string[] = ['Language', 'actions'];
  public languages: Language[] = [];
  public isChecked: boolean;
  public loader: boolean;
  constructor(private languageService: LanguageService,
    private commonService: CommonService,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.getLanguageList();
  }

  ToggleChb(event) {
    this.isChecked = event.checked;
    this.languages.forEach(t => t.Selected = event.checked);
  }

  getLanguageList() {
    this.loader = true;
    this.languageService.languageList().subscribe((res: any) => {
      if (res.Status == 'success') {
        if (res.Data !== null || res.Data !== undefined) {
          this.languages = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  openLanguageDialog(): void {
    const dialogRef = this.dialog.open(AddEditLanguageComponent, {
      width: '500px',
    });
    dialogRef.componentInstance.language.LanguageId = 0;
    dialogRef.componentInstance.language.Name = '';
    dialogRef.componentInstance.language.CodeName = '';

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        // Refresh Education Detail Grid.
        this.getLanguageList();
        this.commonService.toaster('Language added successfully.', true);
      }
    });
  }

  onLanguageDelete(id) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: '350px',
    });
    dialogConfirmRef.componentInstance.message = 'You want to delete this language?';
    dialogConfirmRef.componentInstance.btnOkText = 'Yes';
    dialogConfirmRef.componentInstance.btnCancelText = 'No';

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.languageService.removeLanguage(id).subscribe((res: any) => {
          if (res.Status == 'success') {
            this.getLanguageList();
            this.commonService.toaster('Language deleted successfully.', true);
          } else {
            this.commonService.toaster(res.Message, false);
          }
        });
      }
    });
  }
}

