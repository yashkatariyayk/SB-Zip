import { Injectable } from '@angular/core';
import { HttpClientService } from 'src/app/core/services/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {

  constructor(private httpClient: HttpClientService) { }

  languageList() {
    let url = '/language';
    return this.httpClient.get(url);
  }

  addLanguage(language: any) {
    let url = '/language';
    return this.httpClient.post(url, language);
  }

  removeLanguage(id) {
    let url = '/language?id=' + id;
    return this.httpClient.delete(url);
  }
}
