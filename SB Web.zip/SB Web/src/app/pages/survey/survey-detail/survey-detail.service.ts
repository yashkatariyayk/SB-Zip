import { Injectable } from "@angular/core";
import { AuthService } from "src/app/core/services/auth.service";
import { HttpClientService } from "src/app/core/services/http-client.service";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { RouteConfig } from "src/app/route.config";

@Injectable()
export class SurveyDetailService {
  constructor(
    private httpClient: HttpClientService,
    private auth: AuthService,
    private http: HttpClient,
    private routeConfig: RouteConfig
  ) {}

  saveSelectees(surveySelectees) {
    let url = "/survey/selectee";
    return this.httpClient.post(url, surveySelectees);
    //   let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    //   const httpOptions = { headers: headers };
    //   httpOptions["reportProgress"] = true;
    //   httpOptions["observe"] = 'events';
    //   let body = JSON.stringify(surveySelectees);

    //   let response = this.http.post<any>(this.routeConfig.url(url), body, httpOptions);
    //  // console.log('Res', response);
    //   return response;
  }

  getSelecteeList(SurveyId, filterObject) {
    let url = "/survey/selectee/" + SurveyId;
    return this.httpClient.post(url, filterObject);
  }

  updateSelectee(selectee) {
    let url = "/survey/selectee";
    return this.httpClient.put(url, selectee);
  }

  removeSelectee(SelecteeId) {
    let url = "/survey/selectee?selecteeId=" + SelecteeId;
    return this.httpClient.delete(url);
  }

  removeMultipleSelectees(queryObj: any) {
    let url = "/survey/selectee/delete/many";
    return this.httpClient.post(url, queryObj);
  }

  saveSelectors(surveySelectors) {
    let url = "/survey/selector";
    return this.httpClient.post(url, surveySelectors);
    // let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    // const httpOptions = { headers: headers };
    // httpOptions["reportProgress"] = true;
    // httpOptions["observe"] = 'events';
    // let body = JSON.stringify(surveySelectors);

    // let response = this.http.post<any>(this.routeConfig.url(url), body, httpOptions);
    // console.log('Res', response);
    //   return response;
  }

  updateSelector(selector) {
    let url = "/survey/selector";
    return this.httpClient.put(url, selector);
  }

  getSelectorList(SurveyId, filterObject) {
    let url = "/survey/selector/" + SurveyId;
    return this.httpClient.post(url, filterObject);
  }

  removeSelector(SelectorId) {
    let url = "/survey/selector?selectorId=" + SelectorId;
    return this.httpClient.delete(url);
  }

  removeMultipleSelectors(queryObj) {
    let url = "/survey/selector/delete/many";
    return this.httpClient.post(url, queryObj);
  }

  getSurvey(id) {
    let url = "/survey?id=" + id;
    return this.httpClient.get(url);
  }

  updateSurvey(surveyDetail: any, surveyId) {
    let url = "/survey?id=" + surveyId;
    let input = new FormData();
    input.append("Logo", surveyDetail.Logo);
    input.append("OldLogoName", surveyDetail.OldLogoName);
    input.append("Name", surveyDetail.Name);
    input.append("StartDate", surveyDetail.StartDate);
    input.append("EndDate", surveyDetail.EndDate);
    input.append("SurveyStatusId", surveyDetail.SurveyStatusId);
    return this.httpClient.put(url, input);
  }

  savePage(page: any) {
    let url = "/survey/page";
    return this.httpClient.post(url, page);
  }

  getClientList() {
    let url = "/client";
    return this.httpClient.get(url);
  }

  getSurveyByLanguageId(surveyId: number, languageId: number) {
    let url = "/survey?id=" + surveyId + "&languageId=" + languageId;
    return this.httpClient.get(url);
  }

  getEmailTemplateList() {
    let url = "/emailTemplate";
    return this.httpClient.get(url);
  }

  sendEmailToSelectors(selector: any) {
    let url = "/emailTemplate/sendEmail";
    return this.httpClient.post(url, selector);
  }

  saveEmailLog(selectors: any) {
    let url = "/email";
    return this.httpClient.post(url, selectors);
  }

  getMatrixTypeList() {
    let url = "/matrixType";
    return this.httpClient.get(url);
  }

  languageList() {
    let url = "/language";
    return this.httpClient.get(url);
  }

  getSurveyResponse(surveyId) {
    let url = "/survey/response/" + surveyId;
    return this.httpClient.get(url);
  }

  logout() {
    this.auth.logout();
  }

  getEmailTemplateByLanguage(templateId, languageId) {
    let url = "/emailTemplate/" + templateId + "/" + languageId;
    return this.httpClient.get(url);
  }

  ClearResponse(SurveyId) {
    let url = "/survey/response/" + SurveyId;
    return this.httpClient.delete(url);
  }
}
