import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SurveyDetailComponent } from "./survey-detail.component";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { NgxFileDropModule } from "ngx-file-drop";
import { IgxCarouselModule, IgxSliderModule } from "igniteui-angular";
import { SurveyDetailService } from "./survey-detail.service";
import { SurveyListService } from "../survey-list/survey-list.service";
import { SelecteesComponent } from "./selectees/selectees.component";
import { SelectorsComponent } from "./selectors/selectors.component";
import { LaddaModule } from "angular2-ladda";
import { CreateSurveyService } from "../../create-survey/create-survey.service";
import { CKEditorModule } from "ng2-ckeditor";
import { FormsModule } from "@angular/forms";
import { LanguageComponent } from "./language/language.component";
import { ExportSurveyComponent } from "./export-survey/export-survey.component";
import { InfiniteScrollModule } from "src/app/shared/pipes/infinite-scroll/infinite-scroll.module";
import { NgCircleProgressModule } from "ng-circle-progress";

const routes: Routes = [
  { path: "", component: SurveyDetailComponent, data: { selectedIndex: 0 } }
];

@NgModule({
  declarations: [
    SurveyDetailComponent,
    SelecteesComponent,
    SelectorsComponent,
    LanguageComponent,
    ExportSurveyComponent
  ],
  imports: [
    CommonModule,
    InfiniteScrollModule,
    SharedModule,
    RouterModule.forChild(routes),
    NgxFileDropModule,
    IgxCarouselModule,
    IgxSliderModule,
    LaddaModule,
    CKEditorModule,
    FormsModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#43a393",
      innerStrokeColor: "#C7E596",
      animationDuration: 300
    })
  ],
  exports: [RouterModule],
  providers: [SurveyDetailService, SurveyListService, CreateSurveyService]
})
export class SurveyDetailModule {}
