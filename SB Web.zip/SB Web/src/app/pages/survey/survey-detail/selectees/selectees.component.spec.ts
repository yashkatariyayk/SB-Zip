import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelecteesComponent } from './selectees.component';

describe('SelecteesComponent', () => {
  let component: SelecteesComponent;
  let fixture: ComponentFixture<SelecteesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelecteesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelecteesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
