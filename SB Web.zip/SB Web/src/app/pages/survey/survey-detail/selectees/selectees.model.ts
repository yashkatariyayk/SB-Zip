export class Selectee {
  EmployeeId: number;
  FirstName: string;
  LastName: string;
  Email: string;
  Role: string;
  Department: string;
  Miscellaneous: string;
  SurveySelecteeId: number;
  SurveyId: number;
  CompanyId: number;
  Selected: boolean;
}

export class SurveySelectee {
  Selectee: Selectee[];
  SurveyId: number;
  LastImportedDate: Date;
}

export class EmailTemplate {
  EmailTemplateId: number;
  Title: string;
  Subject: string;
  Body: string;
}

export class FilterObject {
  FirstName: string;
  LastName: string;
  Email: string;
  Role: string;
  Department: string;
  skip: number = 0;
  limit: number = 10;
  direction: string;
  SortColumn: string;
}
