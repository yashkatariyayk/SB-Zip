import {
  Component,
  OnInit,
  ViewChild,
  Input,
  AfterViewInit
} from "@angular/core";
import { ErrorDialogComponent } from "src/app/shared/components/error-dialog/error-dialog.component";
import {
  MatDialog,
  MatPaginator,
  MatSort,
  MatTableDataSource
} from "@angular/material";
import { SurveyDetailService } from "../survey-detail.service";
import { SurveySelectee, FilterObject } from "./selectees.model";
import { CommonService } from "src/app/core/services/common.service";
import { ConfirmDialogComponent } from "src/app/shared/components/confirm-dialog/confirm-dialog.component";
import { UtilityComponent } from "src/app/core/services/utility";
import { FormControl } from "@angular/forms";
import { HttpEvent, HttpEventType } from "@angular/common/http";
import * as Papa from "papaparse";

@Component({
  selector: "app-selectees",
  templateUrl: "./selectees.component.html",
  styleUrls: ["./selectees.component.scss"]
})
export class SelecteesComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild("Employeeform", { static: false }) Employeeform;
  @Input() surveyId: number;
  @Input() isLive: boolean;
  public isShowImport: boolean;
  public loader: boolean;
  public employees: any[] = [];
  public headers: any[] = [];
  public file: any;
  public isChecked: boolean = false;
  public lastImportedDate: Date;
  public surveySelecteeId: number;
  public selectedIds: any = [];
  public sampleHeaders: any[] = [
    "EmployeeId",
    "FirstName",
    "LastName",
    "Email",
    "Role",
    "Department",
    "Miscellaneous"
  ];
  public displayedColumns: string[] = [
    "select",
    "FirstName",
    "LastName",
    "Email",
    "Role",
    "Department",
    "Miscellaneous",
    "actions"
  ];
  public surveySelectee: SurveySelectee = new SurveySelectee();
  public dataSource = new MatTableDataSource<any>(this.employees);
  public pageSize = 10;
  public pageSizeOptions = [5, 10, 25, 100, 200, 250, 500];

  firstNameFilter = new FormControl();
  lastNameFilter = new FormControl();
  emailFilter = new FormControl();
  roleFilter = new FormControl();
  departmentFilter = new FormControl();
  public filteredValues: FilterObject = new FilterObject();
  public totalSize: number = 0;
  public isShowSelectAllDelete: boolean;
  public selectedCount: number = 0;
  public uncheckedSelectee: any = [];
  public percentage: number = 0;
  public IsShowPercentageProgress: boolean = false;

  constructor(
    public dialog: MatDialog,
    private surveyDetailService: SurveyDetailService,
    private commonService: CommonService
  ) {}

  ngOnInit() {
    this.dataSource = new MatTableDataSource<any>(this.employees);
    this.dataSource.paginator = this.paginator;
    this.filteredValues.limit = 10;
    this.filteredValues.skip = 0;
    this.filteredValues.SortColumn = "FirstName";
    this.filteredValues.direction = "asc";
    this.getSelecteeList();
    setInterval(() => {
      this.dataSource.sort = this.sort;
    }, 3000);
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (data, sortHeaderId) =>
      data[sortHeaderId].toLocaleLowerCase();

    this.firstNameFilter.valueChanges.subscribe(firstNameFilterValue => {
      if (firstNameFilterValue) {
        this.filteredValues["FirstName"] = firstNameFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator.pageIndex = 0;
      } else {
        delete this.filteredValues.FirstName;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelecteeList();
    });

    this.lastNameFilter.valueChanges.subscribe(lastNameFilterValue => {
      if (lastNameFilterValue) {
        this.filteredValues["LastName"] = lastNameFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator.pageIndex = 0;
      } else {
        delete this.filteredValues.LastName;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelecteeList();
    });

    this.emailFilter.valueChanges.subscribe(emailFilterValue => {
      if (emailFilterValue.trim()) {
        this.filteredValues["Email"] = emailFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator.pageIndex = 0;
      } else {
        delete this.filteredValues.Email;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelecteeList();
    });

    this.roleFilter.valueChanges.subscribe(roleFilterValue => {
      if (roleFilterValue) {
        this.filteredValues["Role"] = roleFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator.pageIndex = 0;
      } else {
        delete this.filteredValues.Role;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelecteeList();
    });

    this.departmentFilter.valueChanges.subscribe(departmentFilterValue => {
      if (departmentFilterValue) {
        this.filteredValues["Department"] = departmentFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator.pageIndex = 0;
      } else {
        delete this.filteredValues.Department;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelecteeList();
    });
  }

  convertFile(csv: any) {
    this.IsShowPercentageProgress = true;
    this.file = csv.target.files[0];
    const data = this.file.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInput")
      )).value = null);
      this.IsShowPercentageProgress = false;
      return false;
    }
    if (this.file) {
      Papa.parse(this.file, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          this.headers = result.meta.fields;
          let equal = this.compare(this.sampleHeaders, this.headers);
          if (equal === false) {
            let value = ((<HTMLInputElement>(
              document.getElementById("fileInput")
            )).value = null);
            this.IsShowPercentageProgress = false;
            this.showErrorModal();
            return false;
          }
          this.surveySelectee.Selectee = result.data;
          this.surveySelectee.SurveyId = this.surveyId;
          this.surveySelectee.LastImportedDate = UtilityComponent.getUTCDate(
            new Date()
          );
          this.IsShowPercentageProgress = true;
          this.surveyDetailService
            .saveSelectees(this.surveySelectee)
            .subscribe((res: any) => {
              if (res.Status == "success") {
                this.commonService.toaster(res.Message, true);
                this.IsShowPercentageProgress = false;
                this.getSelecteeList();
              } else {
                this.IsShowPercentageProgress = false;
                this.commonService.toaster(res.Message, false);
              }
            });
        }
      });
    }
  }

  async updateProgress(event: HttpEvent<any>) {
    switch (event.type) {
      case HttpEventType.Sent:
        // console.log('Sent');
        break;
      case HttpEventType.Response:
        this.commonService.toaster("Success", true);
        console.log("Respont saved");
        this.getSelecteeList();
        break;
      case HttpEventType.UploadProgress: {
        this.percentage = Math.round((100 * event.loaded) / event.total);

        break;
      }
    }
  }

  ToggleChb(event) {
    this.isChecked = event.checked;
    this.uncheckedSelectee = [];
    this.employees.forEach(t => (t.selected = event.checked));
    let count = this.employees.filter(t => t.selected === true).length;
    this.selectedCount = count > 0 ? this.totalSize : 0;
    count > 0
      ? (this.isShowSelectAllDelete = true)
      : (this.isShowSelectAllDelete = false);
  }

  SingleCheck(event, surveySelecteeId: number) {
    let count = this.employees.filter(t => t.selected === true).length;
    if (this.isShowSelectAllDelete) {
      this.selectedCount =
        event.checked === true
          ? (this.selectedCount += 1)
          : (this.selectedCount -= 1);
    } else {
      this.selectedCount =
        event.checked === true ? count : (this.selectedCount -= 1);
    }
    count > 0
      ? (this.isShowSelectAllDelete = true)
      : (this.isShowSelectAllDelete = false);
    if (event.checked == false && this.isChecked == true) {
      let index = this.uncheckedSelectee.indexOf(surveySelecteeId);
      index == -1 ? this.uncheckedSelectee.push(surveySelecteeId) : false;
    } else {
      let index = this.uncheckedSelectee.indexOf(surveySelecteeId);
      index > -1 ? this.uncheckedSelectee.splice(index, 1) : false;
    }
  }

  compare(arr1, arr2) {
    if (arr1.length !== arr2.length) return false;
    for (let i = 0, len = arr1.length; i < len; i++) {
      if (arr1[i].trim() !== arr2[i].trim()) {
        return false;
      }
    }
    return true;
  }

  showErrorModal() {
    const dialogConfirmRef = this.dialog.open(ErrorDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.title = "Error occurred";
    dialogConfirmRef.componentInstance.message =
      "Error occurred while processing uploaded csv file." +
      "It may be possible file format is not proper or having some invalid data.";
    dialogConfirmRef.componentInstance.btnOkText = "OK";
  }

  getSelecteeList() {
      this.loader = true;
    let filterObject = this.filteredValues;

    this.surveyDetailService
      .getSelecteeList(this.surveyId, filterObject)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          if (res.Data !== null || res.Data !== undefined) {
            if (res.Data.Selectee) {
              this.employees = res.Data.Selectee;
              this.employees.length > 0
                ? (this.isShowImport = false)
                : (this.isShowImport = true);
              this.dataSource.data = res.Data.Selectee as any;
              this.dataSource.sort = this.sort;
              // setTimeout(() => {
              //   this.employees.length > 0 ? (this.isShowImport = false) : (this.isShowImport = true);
              //   this.percentage = 0;
              //   this.IsShowPercentageProgress = false;
              // }, 1000);
              this.dataSource.data.length > 0
                ? (this.isShowImport = false)
                : (this.isShowImport = true);
              //    this.IsShowPercentageProgress = false;
              this.dataSource.data.forEach(element => {
                element.isEdit = false;
              });
              this.lastImportedDate = UtilityComponent.convertUTCDateToLocalDate(
                res.Data.LastImportedDate
              );
              this.totalSize = res.Data.Total;
              this.isChecked == true ? true : false;
              this.isChecked == true
                ? this.employees.forEach(t => (t.selected = true))
                : false;
            } else {
              Object.entries(this.filteredValues).length == 0
                ? (this.employees = [])
                : false;
              Object.entries(this.filteredValues).length == 0
                ? (this.isShowImport = true)
                : false;
              this.dataSource.data = [];
              this.totalSize = 0;
            }
          }
        } else {
          this.commonService.toaster(res.Message, false);
        }
         this.loader = false;
      });
  }

  deleteSelectees(selectees) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to delete this selectee?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        this.surveyDetailService
          .removeSelectee(selectees.SurveySelecteeId)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.loader = false;
              this.getSelecteeList();
              this.commonService.toaster(
                "Selectee deleted successfully.",
                true
              );
            } else {
              this.commonService.toaster(res.Message, false);
            }
            this.loader = false;
          });
      }
    });
  }

  deleteMultiSelecteees() {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to delete this selectee?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        let selectedSelectee: any = [];
        if (!this.isChecked) {
          this.dataSource.data.forEach(selectee => {
            if (selectee.selected) {
              selectedSelectee.push(selectee.SurveySelecteeId);
            }
          });
        }
        let queryObject: any = {};
        queryObject["selecteeIds"] =
          selectedSelectee && selectedSelectee.length > 0
            ? selectedSelectee
            : this.uncheckedSelectee;
        queryObject["IsAllSelected"] = this.isChecked;
        queryObject["SurveyId"] = this.surveyId;
        queryObject["filterObject"] = this.filteredValues;
        this.surveyDetailService
          .removeMultipleSelectees(queryObject)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.isChecked = false;
              this.selectedCount = 0;
              this.filteredValues = new FilterObject();
              this.loader = false;
              this.getSelecteeList();
              this.commonService.toaster(
                "Selectee deleted successfully.",
                true
              );
            } else {
              this.loader = false;
              this.commonService.toaster(res.Message, false);
            }
          });
      }
    });
  }

  onImportBtnClick() {
    this.isShowImport = true;
  }

  backToTable() {
    this.isShowImport = false;
  }

  onEditSelectee(SurveySelecteeId) {
    this.dataSource.data.find(
      t => t.SurveySelecteeId === SurveySelecteeId
    ).isEdit = true;
  }

  onSaveSelectee(selectee) {
    this.loader = true;
    this.surveySelecteeId = selectee.SurveySelecteeId;
    this.surveyDetailService.updateSelectee(selectee).subscribe((res: any) => {
      if (res.Status == "success") {
        this.commonService.toaster("Selectee updated successfully.", true);
        this.employees.find(
          t => t.SurveySelecteeId === this.surveySelecteeId
        ).isEdit = false;
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  ngAfterViewInit() {
    // this.dataSource.paginator = this.paginator;
    // this.dataSource.paginator.length = this.totalSize;
    //  this.dataSource.sort = this.sort;
  }

  handlePage(event) {
    this.filteredValues.skip = event.pageSize * event.pageIndex;
    this.filteredValues.limit = event.pageSize;
    this.getSelecteeList();
  }

  sortChange(event) {
    this.filteredValues.direction = event.direction;
    this.filteredValues.SortColumn = event.active;
    this.getSelecteeList();
  }

  handleInput(event, InputName) {
    switch (InputName) {
      case "FirstName":
        if (event.which === 32 && this.firstNameFilter.value.length === 1) {
          this.firstNameFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["FirstName"] = event.target.value.trim();
          this.getSelecteeList();
        }
        break;
      case "LastName":
        if (event.which === 32 && this.lastNameFilter.value.length === 1) {
          this.lastNameFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["LastName"] = event.target.value.trim();
          this.getSelecteeList();
        }
        break;
      case "Email":
        if (event.which === 32 && this.emailFilter.value.length === 1) {
          this.emailFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["Email"] = event.target.value.trim();
          this.getSelecteeList();
        }
        break;
      case "Role":
        if (event.which === 32 && this.roleFilter.value.length === 1) {
          this.roleFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["Role"] = event.target.value.trim();
          this.getSelecteeList();
        }
        break;
      case "Department":
        if (event.which === 32 && this.departmentFilter.value.length === 1) {
          this.departmentFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["Department"] = event.target.value.trim();
          this.getSelecteeList();
        }
        break;
      default:
        break;
    }
  }
}
