import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  Input,
  ElementRef
} from "@angular/core";
import {
  NgxFileDropEntry,
  FileSystemFileEntry,
  FileSystemDirectoryEntry
} from "ngx-file-drop";
import { CommonService } from "../../../core/services/common.service";
import { SurveyDetail } from "./survey-detail.model";
import { ActivatedRoute } from "@angular/router";
import { ErrorDialogComponent } from "src/app/shared/components/error-dialog/error-dialog.component";
import { MatDialog } from "@angular/material";
import { SurveyDetailService } from "./survey-detail.service";
import { SurveyListService } from "../survey-list/survey-list.service";
import { SurveyStatus, Client } from "../survey-list/survey-list.model";
import {
  Page,
  SurveyPage
} from "src/app/shared/components/survey-common-pages/page.model";
import { environment } from "src/environments/environment";
import { FormControl, Validators } from "@angular/forms";
import { UtilityComponent } from "src/app/core/services/utility";
import { AddQuestionService } from "src/app/shared/components/add-question/add-question.service";
import {
  SurveyQuestionScaleType,
  SurveyQuestionScaleBank,
  MatrixType
} from "src/app/shared/components/add-question/question.model";
import { CreateSurveyService } from "../../create-survey/create-survey.service";
import * as $ from "jquery";
// import { ConfirmDialogComponent } from 'src/app/shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: "app-survey-detail",
  templateUrl: "./survey-detail.component.html",
  styleUrls: ["./survey-detail.component.scss"]
})
export class SurveyDetailComponent implements OnInit, AfterViewInit {
  @ViewChild("Employeeform", { static: false }) Employeeform;
  @ViewChild("fileInput", { static: true }) fileInput: ElementRef;
  @ViewChild("panel", { read: ElementRef, static: false })
  public panel: ElementRef<any>;
  @Input() selectedIndex: number;
  public _ImageUrl: string = environment.IMAGEURL;
  public pageArray = [];
  public pageId: number;
  public surveyId: number;
  public loader: boolean;
  public pageloader: boolean;
  public isLive: boolean = false;
  public isTest: boolean = false;
  public file: any;
  public uploadedfilename: string = "";
  public recipientHeaders: any[] = [];
  public isChecked = false;
  public fileinput: any;
  public startDate: any = "";
  public endDate: any = "";
  public surveyDetail: SurveyDetail = new SurveyDetail();
  public isLoaded: Promise<boolean>;
  public url: any;
  public statusList: SurveyStatus[] = [];
  public surveyQuestionScaleType: SurveyQuestionScaleType[] = [];
  public matrixType: MatrixType[] = [];
  public questionScaleBank: SurveyQuestionScaleBank[] = [];
  public surveyPage: SurveyPage;
  public clientList: Client[] = [];
  public isShowPageBtn: boolean = false;
  // public imgHeight: number;
  //public imgWidth: number;

  surveyNameFormControl = new FormControl("", [Validators.required]);

  constructor(
    private commonService: CommonService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private surveyDetailService: SurveyDetailService,
    private surveyListService: SurveyListService,
    private createSurveyService: CreateSurveyService,
    private addQuestionService: AddQuestionService
  ) {}

  ngOnInit() {
    this.loader = true;
    this.surveyPage = new SurveyPage();
    this.route.params.subscribe(queryParams => {
      let id = queryParams["id"];
      let tabId = queryParams["tabId"];
      if (tabId !== undefined) {
        this.selectedIndex = +tabId;
      }
      if (id !== undefined) {
        this.surveyId = id;
      }
    });
    this.getSurvey(this.surveyId);
    this.getStatusList();
    this.getAllMatrixType();
    this.getAllScaleType();
    this.getAllQuestionScaleBank();
    this.getClientList();
  }
  ngAfterViewInit(): void {
    // this.getSurvey(this.surveyId);
  }

  addComponenet(event) {
    this.getSurvey(this.surveyId);
  }
  UploadImage() {
    $("#file-upload").trigger("click");
  }

  removeComponent(event) {
    let index = this.surveyDetail.surveyPage.findIndex(
      t => t.SurveyPageId === event
    );
    index > -1 ? this.surveyDetail.surveyPage.splice(index, 1) : false;

    // display add new button
    if (
      this.surveyDetail &&
      this.surveyDetail.surveyPage &&
      this.surveyDetail.surveyPage.length > 0
    ) {
      this.surveyDetail.surveyPage[0].SurveyPageTypeId === 1
        ? (this.isShowPageBtn = false)
        : (this.isShowPageBtn = true);
    }
    this.getSurvey(this.surveyId);
  }

  addPage() {
    this.pageloader = true;
    this.surveyPage = new SurveyPage();
    this.surveyPage.Name = "Page Title";
    this.surveyPage.Description = "";
    this.surveyPage.SurveyId = this.surveyDetail.SurveyId;
    this.surveyPage.PageOrder = 1;
    this.surveyDetailService.savePage(this.surveyPage).subscribe((res: any) => {
      if (res.Status == "success") {
        this.pageloader = false;
        this.commonService.toaster("Page added successfully.", true);
        if (res.Data !== null || res.Data !== undefined) {
          this.surveyPage = res.Data;
        }
        this.getSurvey(this.surveyId);
        this.scrollToBottom();
      } else {
        this.pageloader = false;
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  public files: NgxFileDropEntry[] = [];

  dropped(files: NgxFileDropEntry[]) {
    // this.files.push(f);
    files.forEach(element => {
      this.files.push(element);
    });
    for (const droppedFile of files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {});
      } else {
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
      }
    }
  }

  getSurvey(id) {
    this.loader = true;
    this.isLoaded = Promise.resolve(false);
    this.surveyDetailService.getSurvey(id).subscribe((res: any) => {
      if (res.Status == "success") {
        this.uploadedfilename = "";
        this._ImageUrl = environment.IMAGEURL;
        if (res.Data.length > 0) {
          this.surveyDetail = res.Data[0];
        }
        switch (this.surveyDetail.SurveyStatusId) {
          case 1:
            this.isLive = true;
            break;
          case 4:
            this.isTest = true;
            break;

          default:
            this.isLive = false;
            this.isTest = false;
            break;
        }
        // check first page is welcome page or not
        if (
          this.surveyDetail &&
          this.surveyDetail.surveyPage &&
          this.surveyDetail.surveyPage.length > 0
        ) {
          this.surveyDetail.surveyPage[0].SurveyPageTypeId === 1
            ? (this.isShowPageBtn = false)
            : (this.isShowPageBtn = true);
        }

        this.loader = false;
        this.isLoaded = Promise.resolve(true);
        this.startDate = this.surveyDetail.StartDate
          ? UtilityComponent.convertUTCDateToLocalDate(
              this.surveyDetail.StartDate
            )
          : "";
        this.endDate = this.surveyDetail.EndDate
          ? UtilityComponent.convertUTCDateToLocalDate(
              this.surveyDetail.EndDate
            )
          : "";
      } else {
        this.loader = false;
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  getStatusList() {
    this.surveyListService.statusList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.statusList = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  showErrorModal() {
    const dialogConfirmRef = this.dialog.open(ErrorDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.title = "Error occurred";
    dialogConfirmRef.componentInstance.message =
      "Error occurred while processing uploaded csv file." +
      "It may be possible file format is not proper or having some invalid data.";
    dialogConfirmRef.componentInstance.btnOkText = "OK";
  }

  showSuccessModal() {
    const dialogConfirmRef = this.dialog.open(ErrorDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.title = "Success";
    dialogConfirmRef.componentInstance.message = "File imported successfully.";
    dialogConfirmRef.componentInstance.btnOkText = "OK";
  }

  fileUpload(event: any) {
    this.fileinput = event;
    const fileList = this.fileInput.nativeElement;
    if (fileList.files && fileList.files.length > 0 && fileList.files[0]) {
      const file = fileList.files[0];
      if (file) {
        const img = new Image();
        img.src = window.URL.createObjectURL(file);
        const reader = new FileReader();
        reader.onload = (e: any) => {
          //  this.imgWidth = img.naturalWidth;
          //    this.imgHeight = img.naturalHeight;

          //  if (this.imgWidth === 120 && this.imgHeight === 120) {
          this.url = e.target.result;
          this.surveyDetail.LogoName = e.target.result;
          this._ImageUrl = "";
          // } else {
          //   this.fileInput.nativeElement.value = "";
          //   this.commonService.toaster("Please upload 120 X 120px size logo.", false);
          // }
        };
        reader.readAsDataURL(file);
      }
      //    if (this.imgWidth === 120 && this.imgHeight === 120) {
      this.surveyDetail.LogoName
        ? (this.surveyDetail.OldLogoName = this.surveyDetail.LogoName)
        : false;
      this.surveyDetail.LogoName = file.name;
      this.uploadedfilename = file.name;
      this.surveyDetail.Logo = file;
      //   }
    }
  }

  updateSurvey() {
    if (!this.surveyNameFormControl.valid) {
      return false;
    }
    this.loader = true;
    this.startDate
      ? (this.surveyDetail.StartDate = UtilityComponent.getUTCDate(
          this.startDate
        ))
      : false;
    this.endDate
      ? (this.surveyDetail.EndDate = UtilityComponent.getUTCDate(this.endDate))
      : false;
    this.surveyDetailService
      .updateSurvey(this.surveyDetail, this.surveyId)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.loader = false;
          this.getSurvey(this.surveyId);
          this.uploadedfilename = "";
          this.commonService.toaster("Survey updated successfully.", true);
        } else {
          this.loader = false;
          this.commonService.toaster(res.Message, false);
        }
      });
  }

  getClientList() {
    this.createSurveyService.getClientList().subscribe((res: any) => {
      if (res.Status == "success") {
        this.clientList = res.Data;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  changeTabIndex(event) {
    this.selectedIndex = event.index;
    this.selectedIndex == 0 ? this.getSurvey(this.surveyId) : false;
  }

  getAllMatrixType() {
    this.surveyDetailService.getMatrixTypeList().subscribe((res: any) => {
      if (res.Status == "success") {
        this.matrixType = res.Data;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  getAllScaleType() {
    this.addQuestionService.getAllScaleType().subscribe((res: any) => {
      if (res.Status == "success") {
        this.surveyQuestionScaleType = res.Data;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  getAllQuestionScaleBank() {
    this.addQuestionService.getAllQuestionScaleBank().subscribe((res: any) => {
      if (res.Status == "success") {
        this.questionScaleBank = res.Data;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  scrollToBottom(): void {
    this.panel.nativeElement.scrollIntoView({
      behavior: "smooth",
      block: "end",
      inline: "start"
    });
  }

  surveyStatusChange(event) {
    // if (this.isTest && event === 1) {
    //   const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
    //     width: "350px"
    //   });
    //   dialogConfirmRef.componentInstance.message = "You want to clear all existing response?";
    //   dialogConfirmRef.componentInstance.btnOkText = "Yes";
    //   dialogConfirmRef.componentInstance.btnCancelText = "No";
    //   dialogConfirmRef.afterClosed().subscribe(result => {
    //     if (result === true) {
    //       //     this.surveyDetailService.ClearResponse(this.surveyId).subscribe((res: any) => {
    //       //       if (res.Status == "success") {
    //       //         this.commonService.toaster("Response deleted successfully.", true);
    //       //       } else {
    //       //         this.commonService.toaster(res.Message, false);
    //       //       }
    //       //    });
    //     }
    //   });
    // }
  }
}
