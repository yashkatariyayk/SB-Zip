export class ExportSurveyResponse {
    SelectorID: number;
    SelectorEmailAddress: string;
    QuestionID: number;
    QuestionText: string;
    QuestionType: string;
    MatrixQuestionID: number;
    MatrixQuestionText: string;
    SelecteeID: number;
    SelecteeEmailAddress: string;
    Response: string;
}