import {
  SurveyStatus,
  SurveyTheme,
  Client
} from "../survey-list/survey-list.model";
import {
  SurveyQuestion,
  SurveyQuestionOption
} from "src/app/shared/components/add-question/question.model";
import { SurveyPage } from "src/app/shared/components/add-page/page.model";

export class Survey {
  Title: string;
  CreatedDate: string;
  Status: string;
  Id: number;
}

export class SurveyDetail {
  SurveyId: number;
  SurveyLanguageId: number;
  Name: string;
  StartDate: Date;
  EndDate: Date;
  IsDeleted: boolean;
  CreatedBy: string;
  CreatedOn: string;
  ThemeId: number;
  SurveyStatusId: number;
  LanguageId: number;
  ClientId: number;
  IsTemplate: boolean;
  LogoName: string;
  OldLogoName: string;
  Logo: any;
  SurveyStatus: SurveyStatus;
  SurveyTheme: SurveyTheme;
  Client: Client;
  surveyPage: SurveyPage[];
  SurveyQuestion: SurveyQuestion[];
  SurveyQuestionOption: SurveyQuestionOption[];
}
