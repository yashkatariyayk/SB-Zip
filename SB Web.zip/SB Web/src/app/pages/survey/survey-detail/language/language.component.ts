import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { CommonService } from "src/app/core/services/common.service";
import { MatExpansionPanel, MatDialog } from "@angular/material";
import { LanguageService } from "./language.service";
import * as $ from "jquery";
import { ErrorDialogComponent } from "src/app/shared/components/error-dialog/error-dialog.component";
import {
  ExportSurvey,
  SurveySelecteeLanguage,
  ImportSurvey,
  ExportEmailTemplate,
  EmailTemplateLanguage,
  ExportStaticContent,
  StaticContentLanguage
} from "./language.model";
import { SurveyDetail } from "../survey-detail.model";
import { SurveyPage } from "src/app/shared/components/survey-common-pages/page.model";
import {
  SurveyQuestion,
  SurveyQuestionOption
} from "src/app/shared/components/add-question/question.model";
import { Language } from "src/app/pages/language/language";
import * as Papa from "papaparse";

@Component({
  selector: "app-language",
  templateUrl: "./language.component.html",
  styleUrls: ["./language.component.scss"]
})
export class LanguageComponent implements OnInit {
  @ViewChild("languagePanel", { static: false })
  languagePanel: MatExpansionPanel;
  @Input() surveyId: number;

  public sampleHeaders: any[] = [
    "Id",
    "PageId",
    "QuestionId",
    "ParentQuestionId",
    "Code",
    "Language",
    "Title",
    "Description",
    "TargetTitle",
    "TargetDescription",
    "TranslatedId"
  ];
  public surveyHeaders: any[] = [];
  public file: any;
  public ImportedSurvey: ExportSurvey[];
  public ExportSurveyArr: ExportSurvey[];
  public entity: string = "1";
  public languageId: number = 0;
  public ImportSurveyArr: ImportSurvey;

  public ImportSelecteeHeaders: any[] = [
    "SurveySelecteeId",
    "FirstName",
    "LastName",
    "Email",
    "Role",
    "Department",
    "Miscellaneous",
    "TranslatedId"
  ];
  public selecteeHeaders: any[] = [];
  public selecteeFile: any;
  public ImportedSelecteeLanguage: SurveySelecteeLanguage[] = [];
  public ExportSelecteeLanguageArr: SurveySelecteeLanguage[];
  public languages: Language[] = [];
  public ExportEmailTemplateList: ExportEmailTemplate[] = [];
  public emailTemplateFile: any;
  public EmailTemplateLanguageList: EmailTemplateLanguage[] = [];

  public ExportStaticContentList: ExportStaticContent[] = [];
  public StaticContentLanguageList: StaticContentLanguage[] = [];
  public staticContentFile: any;

  public EXCEL_TYPE =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  public EXCEL_EXTENSION = ".xlsx";

  public ExportEmailTemplateHeader: any[] = [
    "Id",
    "Title",
    "Subject",
    "Body",
    "TargetSubject",
    "TargetBody",
    "TranslatedId"
  ];
  public ExportStaticContentHeader: any[] = [
    "Id",
    "Code",
    "Name",
    "Value",
    "TargetValue",
    "TranslatedId"
  ];

  constructor(
    private commonService: CommonService,
    private languageService: LanguageService,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.ExportSurveyArr = [];
    this.ImportSurveyArr = new ImportSurvey();
    this.getLanguageList();
  }

  getLanguageList() {
    this.languageService.languageList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.languages = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  Export() {
    switch (this.entity) {
      case "1":
        this.ExportSurvey();
        break;
      case "2":
        this.ExportSelectee();
        break;
      case "3":
        this.ExportEmailTemplate();
        break;
      case "4":
        this.ExportStaticContent();
        break;
      default:
        break;
    }
  }
  Import() {
    this.entity == "1" ? this.ImportSurvey() : this.ImportSelectee();
  }

  ImportSurvey() {
    $("#fileInputSurvey").trigger("click");
  }

  convertSurveyFile(csv: any) {
    this.file = csv.target.files[0];
    const data = this.file.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInputSurvey")
      )).value = null);
      return false;
    }

    if (this.file) {
      Papa.parse(this.file, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          this.ImportedSurvey = result.data;
          //  console.log('ImportedSurvey:- ', this.ImportedSurvey);
          this.ImportSurveyArr = new ImportSurvey();
          this.ImportSurveyArr.Survey = [];
          this.ImportSurveyArr.SurveyPage = [];
          this.ImportSurveyArr.SurveyQuestions = [];
          this.ImportSurveyArr.SurveyQuestionOptions = [];

          // tslint:disable-next-line:no-shadowed-variable
          this.ImportedSurvey.forEach((element: ExportSurvey) => {
            switch (element.Code) {
              case "SU":
                let surveyObj = new SurveyDetail();
                surveyObj.SurveyId = element.Id;
                surveyObj.Name = element.TargetTitle;
                surveyObj.LanguageId = this.languageId;
                element.TranslatedId || element.TranslatedId != 0
                  ? (surveyObj.SurveyLanguageId = +element.TranslatedId)
                  : false;
                this.ImportSurveyArr.Survey.push(surveyObj);
                break;

              case "PG":
                let pageObj = new SurveyPage();
                pageObj.SurveyId = this.surveyId;
                pageObj.SurveyPageId = element.Id;
                pageObj.Name = element.TargetTitle;
                pageObj.Description = element.TargetDescription;
                pageObj.LanguageId = this.languageId;
                element.TranslatedId || element.TranslatedId != 0
                  ? (pageObj.SurveyPageLanguageId = +element.TranslatedId)
                  : false;
                this.ImportSurveyArr.SurveyPage.push(pageObj);
                break;

              case "QE":
                let queObj = new SurveyQuestion();
                queObj.SurveyQuestionId = element.Id;
                queObj.SurveyId = this.surveyId;
                queObj.SurveyPageId = element.PageId;
                queObj.Name = element.TargetTitle;
                queObj.ParentQuestionId = element.ParentQuestionId;
                queObj.Description = element.TargetDescription;
                queObj.LanguageId = this.languageId;
                element.TranslatedId || element.TranslatedId != 0
                  ? (queObj.SurveyQuestionLanguageId = +element.TranslatedId)
                  : false;
                this.ImportSurveyArr.SurveyQuestions.push(queObj);
                break;

              case "EM":
                let emplyeeMatrix = new SurveyQuestion();
                emplyeeMatrix.SurveyQuestionId = element.Id;
                emplyeeMatrix.SurveyId = this.surveyId;
                emplyeeMatrix.SurveyPageId = element.PageId;
                emplyeeMatrix.Name = element.TargetTitle;
                emplyeeMatrix.ParentQuestionId = element.ParentQuestionId;
                emplyeeMatrix.Description = element.TargetDescription;
                emplyeeMatrix.LanguageId = this.languageId;
                element.TranslatedId || element.TranslatedId != 0
                  ? (emplyeeMatrix.SurveyQuestionLanguageId = +element.TranslatedId)
                  : false;
                this.ImportSurveyArr.SurveyQuestions.push(emplyeeMatrix);
                break;

              case "QO":
                let optionObj = new SurveyQuestionOption();
                optionObj.SurveyQuestionOptionId = element.Id;
                optionObj.SurveyId = this.surveyId;
                optionObj.SurveyQuestionId = element.QuestionId;
                optionObj.Name = element.TargetTitle;
                optionObj.LanguageId = this.languageId;
                element.TranslatedId || element.TranslatedId != 0
                  ? (optionObj.SurveyQuestionOptionLanguageId = +element.TranslatedId)
                  : false;
                this.ImportSurveyArr.SurveyQuestionOptions.push(optionObj);
                break;
              // default:
              //   return tel;
            }
          });
          //    console.log('Array', this.ImportSurveyArr);
          this.SaveSurvey();
        }
      });
    }
  }

  SaveSurvey() {
    //  console.log('ImportSurveyArr', this.ImportSurveyArr);
    this.languageService
      .saveImportedSurvey(this.ImportSurveyArr)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.commonService.toaster(res.Message, true);
          this.ImportSurveyArr = new ImportSurvey();
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputSurvey")
          )).value = null);
        } else {
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputSurvey")
          )).value = null);
          this.commonService.toaster(res.Message, false);
        }
      });
  }

  compare(arr1, arr2) {
    if (arr1.length !== arr2.length) return false;
    for (let i = 0, len = arr1.length; i < len; i++) {
      if (arr1[i].trim() !== arr2[i].trim()) {
        return false;
      }
    }
    return true;
  }

  showErrorModal() {
    const dialogConfirmRef = this.dialog.open(ErrorDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.title = "Error occurred";
    dialogConfirmRef.componentInstance.message =
      "Error occurred while processing uploaded csv file." +
      "It may be possible file format is not proper or having some invalid data.";
    dialogConfirmRef.componentInstance.btnOkText = "OK";
  }

  ExportSurvey() {
    this.GetSurveyBySurveyId();
  }

  async GetSurveyBySurveyId() {
    this.languageService
      .getSurvey(this.surveyId, this.languageId)
      .subscribe((res: any) => {
        let obj = new ExportSurvey();
        let survey = res.Data[0];
        //  console.log('response', res.Data[0]);
        obj.Id = res.Data[0].SurveyId;
        obj.PageId = 0;
        obj.QuestionId = 0;
        obj.ParentQuestionId = 0;
        obj.Code = "SU";
        obj.Language = "English";
        //   obj.Value = '';
        obj.Title = res.Data[0].Name;
        obj.Description = "";
        //   obj.TargetValue = '';
        if (res.Data[0].Language) {
          obj.TargetTitle = res.Data[0].Language.Name.replace(/,/g, " ").trim();
          obj.TargetDescription = "";
          obj.TranslatedId = res.Data[0].Language.SurveyLanguageId;
        } else {
          obj.TargetTitle = "";
          obj.TargetDescription = "";
          obj.TranslatedId = 0;
        }

        this.ExportSurveyArr = [];
        this.ExportSurveyArr.push(obj);
        this.GetAllPages(survey.surveyPage);
        this.exportCSVFile(
          this.sampleHeaders,
          this.ExportSurveyArr,
          "SurveyExport"
        );
      });
  }

  async GetAllPages(pages) {
    pages.forEach(page => {
      let obj = new ExportSurvey();
      obj.Id = page.SurveyPageId;
      obj.PageId = 0;
      obj.QuestionId = 0;
      obj.ParentQuestionId = 0;
      obj.Code = "PG";
      obj.Language = "English";
      //   obj.Value = '';
      obj.Title = page.Name.replace(/,/g, " ").trim();
      if (page.Description !== null && page.Description !== undefined) {
        let description = page.Description.replace(/"/g, '""');
        let replaceAllcomma = description.replace(/,/g, " ");
        obj.Description = '"' + replaceAllcomma.trim() + '"';
      } else {
        obj.Description = null;
      }
      //   obj.TargetValue = '';
      if (page.Language) {
        obj.TargetTitle = page.Language.Name.replace(/,/g, " ").trim();
        let description = page.Language.Description.replace(/"/g, '""');
        let replaceAllcomma = description.replace(/,/g, " ");
        obj.TargetDescription = '"' + replaceAllcomma.trim() + '"';
        obj.TranslatedId = page.Language.SurveyPageLanguageId;
      } else {
        obj.TargetTitle = "";
        obj.TargetDescription = "";
        obj.TranslatedId = 0;
      }
      this.ExportSurveyArr.push(obj);
      this.GetAllQuestions(page.SurveyQuestion);
    });
  }

  async GetAllQuestions(questions) {
    questions.forEach(question => {
      let obj = new ExportSurvey();
      obj.Id = question.SurveyQuestionId;
      obj.PageId = question.SurveyPageId;
      obj.QuestionId = 0;
      obj.ParentQuestionId = question.ParentQuestionId;
      obj.Code = "QE";
      obj.Language = "English";
      obj.Title = question.Name.replace(/,/g, " ").trim();
      if (question.Description !== null && question.Description !== undefined) {
        let description = question.Description.replace(/"/g, '""');
        let replaceAllcomma = description.replace(/,/g, " ");
        obj.Description = '"' + replaceAllcomma.trim() + '"';
      } else {
        obj.Description = "";
      }
      if (question.Language) {
        obj.TargetTitle = question.Language.Name.replace(/,/g, " ").trim();
        let description = question.Language.Description.replace(/"/g, '""');
        let replaceAllcomma = description.replace(/,/g, " ");
        obj.TargetDescription = '"' + replaceAllcomma.trim() + '"';
        obj.TranslatedId = question.Language.SurveyQuestionLanguageId;
      } else {
        obj.TargetTitle = "";
        obj.TargetDescription = "";
        obj.TranslatedId = 0;
      }
      this.ExportSurveyArr.push(obj);
      if (question.ChildQuestion.length > 0) {
        question.ChildQuestion.forEach(childQuestion => {
          let childQueObj = new ExportSurvey();
          childQueObj.Id = childQuestion.SurveyQuestionId;
          childQueObj.PageId = childQuestion.SurveyPageId;
          childQueObj.QuestionId = null;
          childQueObj.ParentQuestionId = childQuestion.ParentQuestionId;
          childQueObj.Code = "EM";
          childQueObj.Language = "English";
          //    childQueObj.Value = '';
          childQueObj.Title = childQuestion.Name.replace(/,/g, " ").trim();
          if (childQueObj.Description) {
            let description = childQueObj.Description.replace(/"/g, '""');
            let replaceAllcomma = description.replace(/,/g, " ");
            childQueObj.Description = '"' + replaceAllcomma.trim() + '"';
          } else {
            childQueObj.Description = "";
          }
          //      childQueObj.TargetValue = 'null';
          if (childQuestion.Language) {
            childQueObj.TargetTitle = childQuestion.Language.Name.replace(
              /,/g,
              " "
            ).trim();
            let description = childQuestion.Language.Description.replace(
              /"/g,
              '""'
            );
            let replaceAllcomma = description.replace(/,/g, " ");
            childQueObj.TargetDescription = '"' + replaceAllcomma.trim() + '"';
            childQueObj.TranslatedId =
              childQuestion.Language.SurveyQuestionLanguageId;
          } else {
            childQueObj.TargetTitle = "";
            childQueObj.TargetDescription = "";
            childQueObj.TranslatedId = 0;
          }
          this.ExportSurveyArr.push(childQueObj);
        });
      }
      this.getAllQuestionOption(question.SurveyQuestionOption);
    });
  }

  async getAllQuestionOption(options) {
    options.forEach(option => {
      let optionObj = new ExportSurvey();
      optionObj.Id = option.SurveyQuestionOptionId;
      optionObj.PageId = 0;
      optionObj.QuestionId = option.SurveyQuestionId;
      optionObj.ParentQuestionId = 0;
      optionObj.Code = "QO";
      optionObj.Language = "English";
      optionObj.Title = option.Name.replace(/,/g, " ").trim();
      optionObj.Description = "";
      if (option.Language) {
        optionObj.TargetTitle = option.Language.Name.replace(/,/g, " ").trim();
        optionObj.TargetDescription = "";
        optionObj.TranslatedId = option.Language.SurveyQuestionOptionLanguageId;
      } else {
        optionObj.TargetTitle = "";
        optionObj.TargetDescription = "";
        optionObj.TranslatedId = 0;
      }
      this.ExportSurveyArr.push(optionObj);
    });
  }

  ImportSelectee() {
    $("#fileInputSelectee").trigger("click");
  }

  convertSelecteeFile(csv: any) {
    this.selecteeFile = csv.target.files[0];
    const data = this.selecteeFile.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInputSelectee")
      )).value = null);
      return false;
    }

    if (this.selecteeFile) {
      Papa.parse(this.selecteeFile, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          this.selecteeHeaders = result.meta.fields;
          let equal = this.compare(
            this.selecteeHeaders,
            this.ImportSelecteeHeaders
          );
          if (equal === false) {
            let value = ((<HTMLInputElement>(
              document.getElementById("fileInputSelectee")
            )).value = null);
            this.showErrorModal();
            return false;
          }
          let Importedresult = [];
          Importedresult = result.data;
          Importedresult.forEach((ImportData: SurveySelecteeLanguage) => {
            ImportData.LanguageId = this.languageId;
            ImportData.SurveySelecteeLanguageId = +ImportData.TranslatedId;
            this.ImportedSelecteeLanguage.push(ImportData);
          });
          this.SaveSelecteeLanguage();
        }
      });
    }
  }

  SaveSelecteeLanguage() {
    this.languageService
      .saveImportedSelectee(this.ImportedSelecteeLanguage)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.commonService.toaster(res.Message, true);
          this.ImportedSelecteeLanguage = [];
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputSelectee")
          )).value = null);
        } else {
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputSelectee")
          )).value = null);
          this.commonService.toaster(res.Message, false);
        }
      });
  }

  ExportSelectee() {
    this.GetSelecteeList();
  }

  GetSelecteeList() {
    this.languageService
      .getSelecteeList(this.surveyId, this.languageId, {})
      .subscribe((res: any) => {
        this.ExportSelecteeLanguageArr = [];
        if (res.Data) {
          let selectee = res.Data.Selectee;
          // console.log("selectee", selectee);
          this.GetSelectee(selectee);
          this.exportCSVFile(
            this.ImportSelecteeHeaders,
            this.ExportSelecteeLanguageArr,
            "SelecteeExport"
          );
        }
      });
  }

  async GetSelectee(selectees) {
    // tslint:disable-next-line: no-shadowed-variable
    selectees.forEach(element => {
      let obj = new SurveySelecteeLanguage();
      obj.SurveySelecteeId = element.SurveySelecteeId;
      if (element.Language) {
        obj.SurveySelecteeId = element.Language.SurveySelecteeId;
        obj.FirstName = element.Language.FirstName.replace(/,/g, " ").trim();
        obj.LastName = element.Language.LastName.replace(/,/g, " ").trim();
        obj.Email = element.Language.Email.replace(/,/g, " ").trim();
        obj.Role = element.Language.Role.replace(/,/g, " ").trim();
        obj.Department = element.Language.Department.replace(/,/g, " ").trim();
        obj.Miscellaneous = element.Language.Miscellaneous.replace(
          /,/g,
          " "
        ).trim();
        obj.TranslatedId = element.Language.SurveySelecteeLanguageId;
      } else {
        obj.FirstName = element.FirstName.replace(/,/g, " ").trim();
        obj.LastName = element.LastName
          ? element.LastName.replace(/,/g, " ").trim()
          : "";
        obj.Email = element.Email
          ? element.Email.replace(/,/g, " ").trim()
          : "";
        obj.Role = element.Role ? element.Role.replace(/,/g, " ").trim() : "";
        obj.Department = element.Department
          ? element.Department.replace(/,/g, " ").trim()
          : "";
        obj.Miscellaneous = element.Miscellaneous
          ? element.Miscellaneous.replace(/,/g, " ").trim()
          : "";
        obj.TranslatedId = 0;
      }
      this.ExportSelecteeLanguageArr.push(obj);
    });
  }

  bindTemplate(event) {}

  ExportEmailTemplate() {
    this.languageService
      .getEmailTemplate(this.languageId)
      .subscribe((res: any) => {
        if (res.Data) {
          this.ExportEmailTemplateList = [];
          let emailTemplates = res.Data;
          emailTemplates.forEach(emailTemplate => {
            let obj = new ExportEmailTemplate();
            obj.Id = emailTemplate.EmailTemplateId;
            obj.Subject = emailTemplate.Subject.replace(/,/g, " ").trim();
            obj.Title = emailTemplate.Title.replace(/,/g, " ").trim();
            let Body = emailTemplate.Body.replace(/"/g, '""');
            let replaceAllcomma = Body.replace(/,/g, " ");
            obj.Body = '"' + replaceAllcomma.trim() + '"';
            if (emailTemplate.Language) {
              obj.TargetSubject = emailTemplate.Language.Subject.replace(
                /,/g,
                " "
              ).trim();
              let replaceAllComma = emailTemplate.Language.Body.replace(
                /,/g,
                " "
              );
              obj.TargetBody = replaceAllComma.trim();
              obj.TranslateId = emailTemplate.Language.EmailTemplateLanguageId;
            } else {
              obj.TargetSubject = "";
              obj.TargetBody = "";
              obj.TranslateId = 0;
            }
            this.ExportEmailTemplateList.push(obj);
          });
          //    console.log("ExportEmailTemplateList", this.ExportEmailTemplateList);
          this.exportCSVFile(
            this.ExportEmailTemplateHeader,
            this.ExportEmailTemplateList,
            "EmailTemplateExport"
          );
        }
      });
  }

  convertEmailTemplateFile(csv: any) {
    this.emailTemplateFile = csv.target.files[0];
    const data = this.emailTemplateFile.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInputEmailTemplate")
      )).value = null);
      return false;
    }

    this.EmailTemplateLanguageList = [];
    let reader: FileReader = new FileReader();
    if (this.emailTemplateFile) {
      Papa.parse(this.emailTemplateFile, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          let EmailTemplateData = [];
          EmailTemplateData = result.data;
          EmailTemplateData.forEach(template => {
            let obj = new EmailTemplateLanguage();
            obj.LanguageId = this.languageId;
            obj.EmailTemplateId = template.Id;
            obj.Subject = template.TargetSubject;
            if (template.TargetBody !== undefined) {
              let body = template.TargetBody.replace(/"/g, '""');
              let replaceAllComma = body.replace(/,/g, " ");
              obj.Body = replaceAllComma.trim();
            } else {
              obj.Body = template.TargetBody;
            }
            obj.EmailTemplateLanguageId = +template.TranslatedId;
            this.EmailTemplateLanguageList.push(obj);
          });
          this.languageService
            .saveImportedEmailTemplate(this.EmailTemplateLanguageList)
            .subscribe((res: any) => {
              if (res.Status == "success") {
                this.commonService.toaster(res.Message, true);
                this.EmailTemplateLanguageList = [];
                let value = ((<HTMLInputElement>(
                  document.getElementById("fileInputEmailTemplate")
                )).value = null);
              } else {
                this.commonService.toaster(res.Message, false);
                let value = ((<HTMLInputElement>(
                  document.getElementById("fileInputEmailTemplate")
                )).value = null);
              }
            });
        }
      });
    }
  }

  ExportStaticContent() {
    this.languageService
      .getStaticContent(this.languageId, this.surveyId)
      .subscribe((res: any) => {
        if (res.Data) {
          this.ExportStaticContentList = [];
          let staticContents = res.Data;
          staticContents.forEach(content => {
            let obj = new ExportStaticContent();
            obj.Id = content.StaticContentId;
            obj.Code = content.Code.replace(/,/g, " ").trim();
            obj.Name = content.Name.replace(/,/g, " ").trim();
            obj.Value = content.Value.replace(/,/g, " ").trim();
            if (content.Language) {
              obj.TargetValue = content.Language.Value.replace(
                /,/g,
                " "
              ).trim();
              obj.TranslatedId = content.Language.StaticContentLanguageId;
            } else {
              obj.TargetValue = "";
              obj.TranslatedId = 0;
            }
            this.ExportStaticContentList.push(obj);
          });
          //  console.log("ExportStaticContent", this.ExportStaticContentList);
          this.exportCSVFile(
            this.ExportStaticContentHeader,
            this.ExportStaticContentList,
            "ExportStaticContent"
          );
        }
      });
  }

  convertStaticContentFile(csv: any) {
    this.staticContentFile = csv.target.files[0];
    const data = this.staticContentFile.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInputStaticContent")
      )).value = null);
      return false;
    }

    this.StaticContentLanguageList = [];
    if (this.staticContentFile) {
      Papa.parse(this.staticContentFile, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          let headers = result.meta.fields;
          let equal = this.compare(this.ExportStaticContentHeader, headers);
          if (equal === false) {
            let value = ((<HTMLInputElement>(
              document.getElementById("fileInputStaticContent")
            )).value = null);
            this.showErrorModal();
            return false;
          }
          let ImportedStaticContent = [];
          ImportedStaticContent = result.data;
          ImportedStaticContent.forEach(content => {
            let obj = new StaticContentLanguage();
            obj.LanguageId = this.languageId;
            obj.StaticContentId = content.Id;
            obj.Value = content.TargetValue;
            obj.SurveyId = this.surveyId;
            obj.StaticContentLanguageId = +content.TranslatedId;
            this.StaticContentLanguageList.push(obj);
          });
          this.SaveImportedStaticContent();
        }
      });
    }
  }

  SaveImportedStaticContent() {
    this.languageService
      .saveImportedStaticContent(this.StaticContentLanguageList)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.commonService.toaster(res.Message, true);
          this.StaticContentLanguageList = [];
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputStaticContent")
          )).value = null);
        } else {
          this.commonService.toaster(res.Message, false);
          let value = ((<HTMLInputElement>(
            document.getElementById("fileInputStaticContent")
          )).value = null);
        }
      });
  }

  exportCSVFile(headers, items, fileTitle) {
    if (headers) {
      items.unshift(headers);
    }

    // Convert Object to JSON
    let jsonObject = JSON.stringify(items);

    let csv = this.convertToCSV(jsonObject);

    let exportedFilenmae = fileTitle + ".csv" || "exportSurveyResponse.csv";
    //  console.log('ExportSurveyArr', this.ExportSurveyArr);
    let blob = new Blob(["\ufeff" + csv], { type: "text/csv; charset=utf8;" });
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
      let link = document.createElement("a");
      if (link.download !== undefined) {
        // feature detection
        // Browsers that support HTML5 download attribute
        let url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", exportedFilenmae);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  convertToCSV(objArray) {
    let array = typeof objArray != "object" ? JSON.parse(objArray) : objArray;
    // let index = array[0].findIndex(t => t === 'TransatedId');
    //   array[0].splice(index, 1);
    let str = "";

    for (let i = 0; i < array.length; i++) {
      let line = "";
      for (let index in array[i]) {
        //  if (index !== 'TranslatedId') {
        if (line != "") line += ",";

        line += array[i][index];
        // } else {
        //  }
      }
      str += line + "\r\n";
    }
    return str;
  }
}
