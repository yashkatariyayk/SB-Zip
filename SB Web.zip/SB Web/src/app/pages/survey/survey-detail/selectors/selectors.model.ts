export class Selector {
  SurveySelectorId: number;
  SurveyId: number;
  EmployeeId: number;
  Status: any;
  FirstName: string;
  LastName: string;
  Email: string;
  Hash: string;
  StartDate: string;
  EndDate: string;
  SurveySelectorStatusId: number;
  CompletedPageId: number;
  LastAccessedPageId: number;
  Selected: boolean;
  Language: string;
}

export class SurveySelector {
  Selector: Selector[];
  SurveyId: number;
  LastImportedDate: Date;
}

export class EmailLog {
  EmailLogId: number;
  SurveySelectorId: number;
  Email: string;
  Subject: string;
  Body: string;
  Status: string;
  TriedCount: number;
  IsDeleted: boolean;
}
export class SelectorFilterObject {
  FirstName: string;
  LastName: string;
  Email: string;
  SurveySelectorStatusId: number;
  Language: string;
  skip: number = 0;
  limit: number = 10;
}
