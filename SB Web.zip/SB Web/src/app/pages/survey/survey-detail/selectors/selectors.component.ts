import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ElementRef,
  AfterViewInit,
  ChangeDetectorRef
} from "@angular/core";
import { ErrorDialogComponent } from "src/app/shared/components/error-dialog/error-dialog.component";
import {
  MatDialog,
  MatPaginator,
  MatTableDataSource,
  MatSort
} from "@angular/material";
import { SurveySelector, SelectorFilterObject } from "./selectors.model";
import { SurveyDetailService } from "../survey-detail.service";
import { CommonService } from "src/app/core/services/common.service";
import { ConfirmDialogComponent } from "src/app/shared/components/confirm-dialog/confirm-dialog.component";
import { UtilityComponent } from "src/app/core/services/utility";
import { EmailTemplate } from "../selectees/selectees.model";
import { environment } from "src/environments/environment";
import { FormControl } from "@angular/forms";
import { Language } from "src/app/pages/language/language";
import { HttpEventType, HttpEvent } from "@angular/common/http";
import * as Papa from "papaparse";

@Component({
  selector: "app-selectors",
  templateUrl: "./selectors.component.html",
  styleUrls: ["./selectors.component.scss"]
})
export class SelectorsComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @Input() surveyId: number;
  @Input() surveyName: string;
  @Input() isLive: boolean;
  @Input() isTest: boolean;
  public isShowImport: boolean;
  public isShowEmailForm: boolean;
  public isShowEmailBtn: boolean;
  public displayedColumns: string[] = [
    "select",
    "FirstName",
    "LastName",
    "Email",
    "SelectorStatus",
    "Language",
    "actions"
  ];
  public sampleHeaders: any[] = [
    "EmployeeId",
    "FirstName",
    "LastName",
    "Email",
    "Language"
  ];
  public recipientHeaders: any[] = [];
  public recipients: any[] = [];
  public file: any;
  public isChecked: boolean;
  public surveySelectors: SurveySelector = new SurveySelector();
  public lastImportedDate: Date;
  public loader: boolean;
  public emailTemplateList: EmailTemplate[] = [];
  public templateBody: string = "";
  public templateSubject: string = "";
  public SurveySelectorId: number;
  public toAddedToken: boolean;
  public AddedTokenTag: string = "";
  baseURL: string = environment.RootUrl;
  public surveyUrl: string = environment.SurveyUrl;
  public dataSource = new MatTableDataSource<any>(this.recipients);
  public pageSize = 10;
  public pageSizeOptions = [5, 10, 25, 100, 200, 250, 500];
  public languages: Language[] = [];
  public selectedEmailTemplateId: number = 0;
  public defaultLanguageId: number;
  public languageId: number;
  public totalSize: number = 0;
  public translatedSurveyName: string;

  public selectedCount: number = 0;
  public uncheckedSelector: any = [];

  firstNameFilter = new FormControl();
  lastNameFilter = new FormControl();
  emailFilter = new FormControl();
  statusFilter = new FormControl();
  languageFilter = new FormControl();
  public filteredValues: SelectorFilterObject = new SelectorFilterObject();
  public percentage: number = 0;
  public IsShowPercentageProgress: boolean = false;

  constructor(
    public dialog: MatDialog,
    private surveyDetailService: SurveyDetailService,
    private commonService: CommonService,
    private cdRef: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource<any>(this.recipients);
    this.filteredValues.limit = 10;
    this.filteredValues.skip = 0;
    this.getSelectorList();
    this.getLanguageList();
    this.getEmailTemplate();
    setInterval(() => {
      this.dataSource.sort = this.sort;
    }, 3000);
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (data, sortHeaderId) =>
      data[sortHeaderId].toLocaleLowerCase();

    this.firstNameFilter.valueChanges.subscribe(firstNameFilterValue => {
      if (firstNameFilterValue) {
        this.filteredValues["FirstName"] = firstNameFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator ? this.paginator.pageIndex = 0 : false;
      } else {
        delete this.filteredValues.FirstName;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelectorList();
    });

    this.lastNameFilter.valueChanges.subscribe(lastNameFilterValue => {
      if (lastNameFilterValue) {
        this.filteredValues["LastName"] = lastNameFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator ? this.paginator.pageIndex = 0 : false;
      } else {
        delete this.filteredValues.LastName;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelectorList();
    });

    this.emailFilter.valueChanges.subscribe(emailFilterValue => {
      if (emailFilterValue) {
        this.filteredValues["Email"] = emailFilterValue.trim();
        this.filteredValues["skip"] = 0;
        this.paginator ? this.paginator.pageIndex = 0 : false;
      } else {
        delete this.filteredValues.Email;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelectorList();
    });

    this.statusFilter.valueChanges.subscribe(statusFilterValue => {
      if (statusFilterValue != 0) {
        this.filteredValues["SurveySelectorStatusId"] = statusFilterValue;
        this.filteredValues["skip"] = 0;
        this.paginator ? this.paginator.pageIndex = 0 : false;
      } else {
        delete this.filteredValues.SurveySelectorStatusId;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelectorList();
    });

    this.languageFilter.valueChanges.subscribe(languageFilterValue => {
      if (languageFilterValue != 0) {
        this.filteredValues["Language"] = languageFilterValue;
        this.filteredValues["skip"] = 0;
        this.paginator ? this.paginator.pageIndex = 0 : false;
      } else {
        delete this.filteredValues.Language;
        delete this.filteredValues.skip;
        this.paginator ? delete this.paginator.pageIndex : false;
      }
      this.getSelectorList();
    });
  }

  getSelectorList() {
    // this.loader = true;
    let filterObject = this.filteredValues;
    this.surveyDetailService.getSelectorList(this.surveyId, filterObject).subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          if (res.Data.Selector) {
            this.recipients = res.Data.Selector;
            this.dataSource.data = res.Data.Selector as any;
            //  this.dataSource.sort = this.sort;
            this.dataSource.data.forEach(element => {
              element.isEdit = false;
              element.SelectorStatus = element.Status[0].Name;
            });
            // setTimeout(() => {
            //   this.recipients.length > 0 ? (this.isShowImport = false) : (this.isShowImport = true);
            //   this.percentage = 0;
            //   this.IsShowPercentageProgress = false;
            // }, 1000);

            this.dataSource.data.length > 0 ? (this.isShowImport = false) : (this.isShowImport = true);
            this.lastImportedDate = UtilityComponent.convertUTCDateToLocalDate(res.Data.LastImportedDate);
            this.totalSize = res.Data.Total;
            this.isChecked == true ? true : false;
            this.isChecked == true ? this.recipients.forEach(t => (t.selected = true)) : false;
            this.isChecked == true ? this.isShowEmailBtn = true : this.isShowEmailBtn = false;
            // setTimeout(() => {
            //   this.dataSource.paginator = this.paginator;
            // }, 500);
          } else {
            Object.entries(this.filteredValues).length == 0 ? (this.recipients = []) : false;
            Object.entries(this.filteredValues).length == 0 ? (this.isShowImport = true) : false;
            this.dataSource.data = [];
            this.recipients = [];
            this.isShowEmailBtn = false;
            this.totalSize = 0;
          }
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      //  this.loader = false;
    });
  }

  getLanguageList() {
    this.loader = true;
    this.surveyDetailService.languageList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data) {
          this.languages = res.Data;
          this.defaultLanguageId = this.languages.find(
            t => t.Name === "English"
          ).LanguageId;
          this.languageId = this.defaultLanguageId;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  convertRecipientFile(csv: any) {
    this.IsShowPercentageProgress = true;
    this.file = csv.target.files[0];
    const data = this.file.name.split(".");
    if (data[1] !== "csv") {
      this.commonService.toaster("Upload only csv file.", false);
      let value = ((<HTMLInputElement>(
        document.getElementById("fileInputRecipients")
      )).value = null);
      this.IsShowPercentageProgress = false;
      return false;
    }

    if (this.file) {
      Papa.parse(this.file, {
        header: true,
        skipEmptyLines: true,
        complete: (result, file) => {
          this.recipientHeaders = result.meta.fields;
          let equal = this.compare(this.sampleHeaders, this.recipientHeaders);
          if (equal === false) {
            let value = ((<HTMLInputElement>(
              document.getElementById("fileInputRecipients")
            )).value = null);
            this.IsShowPercentageProgress = false;
            this.showErrorModal();
            return false;
          }
          this.surveySelectors.Selector = result.data;
          this.surveySelectors.SurveyId = this.surveyId;
          this.surveySelectors.LastImportedDate = UtilityComponent.getUTCDate(
            new Date()
          );
          this.IsShowPercentageProgress = true;
          this.surveyDetailService
            .saveSelectors(this.surveySelectors)
            .subscribe((res: any) => {
              // this.updateProgress(res);
              if (res.Status == "success") {
                this.commonService.toaster(res.Message, true);
                this.IsShowPercentageProgress = false;
                this.getSelectorList();
              } else {
                this.IsShowPercentageProgress = false;
                this.commonService.toaster(res.Message, false);
              }
            });
        }
      });
    }
  }

  async updateProgress(event: HttpEvent<any>) {
    switch (event.type) {
      case HttpEventType.Sent:
        //  console.log('Sent');
        break;
      case HttpEventType.Response:
        this.commonService.toaster("Success", true);
        this.getSelectorList();
        break;
      case HttpEventType.UploadProgress: {
        this.percentage = Math.round((100 * event.loaded) / event.total);
        break;
      }
    }
  }

  compare(arr1, arr2) {
    if (arr1.length !== arr2.length) return false;
    for (let i = 0, len = arr1.length; i < len; i++) {
      if (arr1[i].trim() !== arr2[i].trim()) {
        return false;
      }
    }
    return true;
  }

  showErrorModal() {
    const dialogConfirmRef = this.dialog.open(ErrorDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.title = "Error occurred";
    dialogConfirmRef.componentInstance.message =
      "Error occurred while processing uploaded csv file." +
      "It may be possible file format is not proper or having some invalid data.";
    dialogConfirmRef.componentInstance.btnOkText = "OK";
  }

  ToggleChb(event) {
    this.uncheckedSelector = [];
    this.isChecked = event.checked;
    this.recipients.forEach(t => (t.selected = event.checked));
    let count = this.recipients.filter(t => t.selected === true).length;
    this.selectedCount = count > 0 ? this.totalSize : 0;
    count > 0 ? (this.isShowEmailBtn = true) : (this.isShowEmailBtn = false);
  }

  onChangechn(event, surveySelectorId) {
    let count = this.recipients.filter(t => t.selected === true).length;
    if (this.isShowEmailBtn) {
      this.selectedCount =
        event.checked === true
          ? (this.selectedCount += 1)
          : (this.selectedCount -= 1);
    } else {
      this.selectedCount =
        event.checked === true ? count : (this.selectedCount -= 1);
    }
    count > 0 ? (this.isShowEmailBtn = true) : (this.isShowEmailBtn = false);
    if (event.checked == false && this.isChecked == true) {
      let index = this.uncheckedSelector.indexOf(surveySelectorId);
      index == -1 ? this.uncheckedSelector.push(surveySelectorId) : false;
    } else {
      let index = this.uncheckedSelector.indexOf(surveySelectorId);
      index > -1 ? this.uncheckedSelector.splice(index, 1) : false;
    }
  }

  deleteSelector(selector) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to delete this selector?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.surveyDetailService
          .removeSelector(selector.SurveySelectorId)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.getSelectorList();
              this.commonService.toaster(
                "Selector deleted successfully.",
                true
              );
            } else {
              this.commonService.toaster(res.Message, false);
            }
          });
      }
    });
  }

  deleteMultiSelectors() {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to delete this selector?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        let slectedSelector: any = [];
        if (!this.isChecked) {
          this.recipients.forEach(selector => {
            if (selector.selected) {
              slectedSelector.push(selector.SurveySelectorId);
            }
          });
        }
        let queryObject: any = {};
        queryObject["selectorIds"] =
          slectedSelector && slectedSelector.length > 0
            ? slectedSelector
            : this.uncheckedSelector;
        queryObject["IsAllSelected"] = this.isChecked;
        queryObject["SurveyId"] = this.surveyId;
        queryObject["filterObject"] = this.filteredValues;
        this.surveyDetailService
          .removeMultipleSelectors(queryObject)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.loader = false;
              this.isChecked = false;
              this.selectedCount = 0;
              this.filteredValues = new SelectorFilterObject();
              this.getSelectorList();
              this.commonService.toaster(
                "Selector deleted successfully.",
                true
              );
            } else {
              this.loader = false;
              this.commonService.toaster(res.Message, false);
            }
          });
      }
    });
  }

  onImportBtnClick() {
    this.isShowImport = true;
  }

  sendMail() {
    this.isShowEmailForm = !this.isShowEmailForm;
  }

  backForm() {
    this.isShowEmailForm = false;
    this.cdRef.detectChanges();
  }

  backToTable() {
    this.isShowImport = false;
  }

  getEmailTemplate() {
    this.loader = true;
    this.surveyDetailService.getEmailTemplateList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.emailTemplateList = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  bindEmailTemplate(event) {
    let selected = +event.value;
    this.selectedEmailTemplateId = selected;
    this.languageId = this.defaultLanguageId;
    selected === 0
      ? (this.templateBody = "")
      : (this.templateBody = this.emailTemplateList.find(
        t => t.EmailTemplateId === selected
      ).Body);
    selected === 0
      ? (this.templateSubject = "")
      : (this.templateSubject = this.emailTemplateList.find(
        t => t.EmailTemplateId === selected
      ).Subject);
  }

  sendMailToSelectors(surveyName) {
    this.loader = true;
    let recipients = [];
    let templateBody = "";

    if (!this.isChecked) {
      recipients = this.recipients.filter(t => t.selected === true);
      recipients.forEach(element => {
        let surveyLink = this.surveyUrl + "survey/" + this.surveyId + "/" + element.Hash;
        let replaceSqureBracket = this.templateBody.replace(/[\[\]']+/g, "");
        let body = this.replaceAll(
          replaceSqureBracket,
          "@SendToUserName",
          element.FirstName
        );
        let body1;
        surveyName && surveyName !== ""
          ? (body1 = this.replaceAll(body, "@SurveyName", surveyName))
          : (body1 = this.replaceAll(body, "@SurveyName", this.surveyName));
        //    let body1 = this.replaceAll(body, "@SurveyName", this.surveyName);
        let body2 = this.replaceAll(body1, "@Link", surveyLink);
        let body3 = body2.replace(
          "@SurveyLink",
          '<a href=" ' + surveyLink + '" target="_blank">Click here.</a>'
        );
        element.Body = body3;
        element.Status = element.Status[0].SurveySelectorStatusId;
        element.Subject = this.templateSubject;
      });
    }
    if (this.isChecked) {
      let surveyLink = this.surveyUrl + "survey/" + this.surveyId + "/@HashKey";
      let replaceSqureBracket = this.templateBody.replace(/[\[\]']+/g, "");
      let body1;
      surveyName && surveyName !== ""
        ? (body1 = this.replaceAll(
          replaceSqureBracket,
          "@SurveyName",
          surveyName
        ))
        : (body1 = this.replaceAll(
          replaceSqureBracket,
          "@SurveyName",
          this.surveyName
        ));
      let body2 = this.replaceAll(body1, "@Link", surveyLink);
      let body3 = body2.replace(
        "@SurveyLink",
        '<a href=" ' + surveyLink + '" target="_blank">Click here.</a>'
      );
      templateBody = body3;
    }
    let queryObject: any = {};
    queryObject["SurveySelectorIds"] = this.uncheckedSelector;
    queryObject["Selector"] = recipients;
    queryObject["IsAllSelected"] = this.isChecked;
    queryObject["SurveyId"] = this.surveyId;
    queryObject["filterObject"] = this.filteredValues;
    queryObject["Subject"] = this.templateSubject;
    queryObject["Body"] = templateBody;
    this.surveyDetailService.saveEmailLog(queryObject).subscribe((res: any) => {
      if (res.Status == "success") {
        this.isShowEmailForm = false;
        this.isChecked = false;
        this.selectedCount = 0;
        this.filteredValues = new SelectorFilterObject();
        this.commonService.toaster("Email will send shortly.", true);
        this.getSelectorList();
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
    this.loader = false;
  }

  onEditSelector(SurveySelectorId) {
    this.recipients.find(
      t => t.SurveySelectorId === SurveySelectorId
    ).isEdit = true;
  }

  async getSurveyByLanguageId() {
    if (this.languageId !== this.defaultLanguageId) {
      this.surveyDetailService
        .getSurveyByLanguageId(this.surveyId, this.languageId)
        .subscribe((res: any) => {
          if (res.Status == "success") {
            if (res.Data.length > 0) {
              let TranslatedSurveyName;
              res.Data[0].Language
                ? (TranslatedSurveyName = res.Data[0].Language.Name)
                : false;
              TranslatedSurveyName && TranslatedSurveyName !== ""
                ? this.sendMailToSelectors(TranslatedSurveyName)
                : this.sendMailToSelectors(this.surveyName);
            }
          } else {
            this.commonService.toaster(res.Message, false);
          }
          this.loader = false;
        });
    } else {
      this.sendMailToSelectors(this.surveyName);
    }
  }

  replaceAll(originalString, find, replace) {
    return originalString.replace(new RegExp(find, "g"), replace);
  }

  onSaveSelector(selector) {
    this.SurveySelectorId = selector.SurveySelectorId;
    this.surveyDetailService.updateSelector(selector).subscribe((res: any) => {
      if (res.Status == "success") {
        this.commonService.toaster("Selector updated successfully.", true);
        this.recipients.find(
          t => t.SurveySelectorId === this.SurveySelectorId
        ).isEdit = false;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  AddToken(str) {
    document.getElementById("html").focus();
    this.AddedTokenTag = "[@" + str + "]";
    this.toAddedToken = true;
  }

  ckEditorFocusOut(event) {
    if (this.toAddedToken) {
      event.editor.insertHtml(this.AddedTokenTag);
    }
    this.toAddedToken = false;
  }

  ngAfterViewInit() {
    // this.dataSource.paginator = this.paginator;
    //  this.dataSource.sort = this.sort;
  }

  bindLanguage(event) {
    let selectedLanguage = +event.value;
    this.surveyDetailService
      .getEmailTemplateByLanguage(
        this.selectedEmailTemplateId,
        selectedLanguage
      )
      .subscribe((res: any) => {
        if (res.Data[0].Language) {
          this.templateBody = res.Data[0].Language.Body;
          this.templateSubject = res.Data[0].Language.Subject;
        } else {
          this.templateBody = res.Data[0].Body;
          this.templateSubject = res.Data[0].Subject;
        }
      });
  }

  handlePage(event) {
    this.filteredValues.skip = event.pageSize * event.pageIndex;
    this.filteredValues.limit = event.pageSize;
    this.getSelectorList();
  }

  handleInput(event, InputName) {
    switch (InputName) {
      case "FirstName":
        if (event.which === 32 && this.firstNameFilter.value.length === 1) {
          this.firstNameFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["FirstName"] = event.target.value.trim();
          this.getSelectorList();
        }
        break;
      case "LastName":
        if (event.which === 32 && this.lastNameFilter.value.length === 1) {
          this.lastNameFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["LastName"] = event.target.value.trim();
          this.getSelectorList();
        }
        break;
      case "Email":
        if (event.which === 32 && this.emailFilter.value.length === 1) {
          this.emailFilter.setValue(null);
          event.preventDefault();
          return false;
        } else {
          this.filteredValues["Email"] = event.target.value.trim();
          this.getSelectorList();
        }
        break;
      default:
        break;
    }
  }

  clearResponse() {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to clear all existing response?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        this.surveyDetailService
          .ClearResponse(this.surveyId)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.commonService.toaster(
                "Response deleted successfully.",
                true
              );
            } else {
              this.commonService.toaster(res.Message, false);
            }
            this.loader = false;
          });
      }
    });
  }
}
