import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  public isExpanded: boolean;
  public isClient: boolean;
  public toggleList: boolean;
  constructor(private router: Router) { }

  ngOnInit() {
    if (this.router.url === '/language' || (this.router.url === '/email-server')) {
      this.toggleList = true;
    }
    this.isExpanded = true;
  }

}
