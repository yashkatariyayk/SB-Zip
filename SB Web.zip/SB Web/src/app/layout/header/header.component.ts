import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public isProxyUser: boolean;
  public profilePic: string;
  public pageTitle: string;
  constructor(private router: Router) {
    router.events.subscribe((val) => {
      // change page title on page change
      if (val instanceof NavigationEnd) {
        let routeName = this.router.url.replace(/[/-]/g, ' ');
        this.pageTitle = routeName;
        if (this.router.url.includes('survey/survey-detail')) {
          this.pageTitle = 'survey detail';
        }
      }
    });
  }

  ngOnInit() {
  }

  logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('isRememberMe');
    localStorage.removeItem('UserName');
    this.router.navigate(['./login']);
  }

}
