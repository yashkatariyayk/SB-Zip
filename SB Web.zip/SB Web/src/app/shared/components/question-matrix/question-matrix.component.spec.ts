import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionMatrixComponent } from './question-matrix.component';

describe('QuestionMatrixComponent', () => {
  let component: QuestionMatrixComponent;
  let fixture: ComponentFixture<QuestionMatrixComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionMatrixComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionMatrixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
