import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-question-matrix',
  templateUrl: './question-matrix.component.html',
  styleUrls: ['./question-matrix.component.scss']
})
export class QuestionMatrixComponent implements OnInit {
@Input() question: any;
  constructor() { }

  ngOnInit() {
  }

}
