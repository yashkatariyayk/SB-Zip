import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouteConfig } from 'src/app/route.config';
import { AuthService } from 'src/app/core/services/auth.service';
import { HttpClientService } from 'src/app/core/services/http-client.service';


@Injectable()
export class AddQuestionService {
    constructor(private http: HttpClient,
        private routeConfig: RouteConfig,
        private httpClient: HttpClientService,
        private auth: AuthService) { }


    getAllScaleType() {
        let url = '/survey/question/scaleType';
        return this.httpClient.get(url);
    }

    getAllQuestionScaleBank() {
        let url = '/survey/question/scaleBank';
        return this.httpClient.get(url);
    }

    saveQuestion(question: any) {
        let url = '/survey/question';
        return this.httpClient.post(url, question);
    }

    updateQuestion(question: any) {
        let url = '/survey/question';
        return this.httpClient.put(url, question);
    }

    removeQuestion(questionId) {
        let url = '/survey/question?questionId=' + questionId;
        return this.httpClient.delete(url);
    }

    getQuestionByQuestionId(questionId) {
        let url = '/survey/question?questionId=' + questionId;
        return this.httpClient.get(url);
    }

}
