import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxTextInputComponent } from './checkbox-text-input.component';

describe('CheckboxTextInputComponent', () => {
  let component: CheckboxTextInputComponent;
  let fixture: ComponentFixture<CheckboxTextInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckboxTextInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxTextInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
