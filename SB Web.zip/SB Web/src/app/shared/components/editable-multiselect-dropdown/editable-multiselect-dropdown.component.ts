import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  HostListener
} from "@angular/core";
import { FormControl, Validators } from "@angular/forms";
import { Observable } from "rxjs";
import { map, startWith } from "rxjs/operators";
import { SelecteeFilter } from "./editable-multiselect-dropdown";
import { SurveyDetailService } from "src/app/pages/survey/survey-detail/survey-detail.service";

@Component({
  selector: "app-editable-multiselect-dropdown",
  templateUrl: "./editable-multiselect-dropdown.component.html",
  styleUrls: ["./editable-multiselect-dropdown.component.scss"]
})
export class EditableMultiselectDropdownComponent implements OnInit, OnChanges {
  @HostListener("document:keydown", ["$event"])
  @ViewChild("multiselectdropdown", { static: true })
  dropdown: ElementRef;
  @ViewChild("search", { static: true }) searchTextBox: ElementRef;
  @Input() dropDownList: any[] = [];
  @Input() isSaveRequired = false;
  @Input() isSearchRequired = false;
  @Input() surveyId: number;
  @Output() emitSelectedValues = new EventEmitter<any>();
  @Output() saveNewValue = new EventEmitter<any>();

  public selectFormControl = new FormControl();
  public searchTextboxControl = new FormControl();
  public selectedValues = [];
  // public filteredOptions: Observable<any[]>;
  public filteredOptions: any[] = [];
  public multiSelectPlaceholder: string = "Select a person";
  public checkAnswer: boolean;
  public openFilterTab: boolean;
  public isReadOnly: boolean = true;
  public openAddSelecteeTab: boolean;
  public filter: SelecteeFilter = new SelecteeFilter();
  public addSelectee: SelecteeFilter = new SelecteeFilter();
  public pageSize: number = 100;
  public pageNum: number = 1;
  public isSelecteeComplete: boolean;
  public isEnd: boolean;

  constructor(private surveyDetailService: SurveyDetailService) {}

  ngOnInit() {
    this.selectFormControl.setValue([]);
    this.filteredOptions = this.dropDownList;
    this.isSearchRequired;
    this.openAddSelecteeTab = true;
    this.openFilterTab = true;
  }

  ngOnChanges() {
    if (!this.isSearchRequired) {
      this.isSaveRequired = false;
    }
    this.filteredOptions = this.dropDownList;
  }

  // Remove from selected values based on uncheck
  selectionChange(event) {
    if (event.isUserInput && event.source.selected === false) {
      // Uncheck selected Item in and remove from selected array
      let index = this.selectedValues.findIndex(
        t => t.SurveySelecteeId === event.source.value
      );
      this.selectedValues.splice(index, 1);
      this.emitSelectedValues.emit(this.selectedValues);
    } else {
      if (event.callFromParent && event.selected === false) {
        // Delete selected item from array when user remove selectee from table
        let index = this.selectedValues.findIndex(
          t => t.SurveySelecteeId === event.SurveySelecteeId
        );
        this.selectedValues.splice(index, 1);

        // Update selected item in dropdown
        this.setSelectedValues();
      } else {
        // When user check selectee, Check and add new selectee
        this.addSelectedItem(event);
      }
    }
  }

  addSelectedItem(event) {
    let isExisting = this.selectedValues.filter(
      x => x.SurveySelecteeId == event.source.value
    )[0];
    if (!isExisting && event.source.selected) {
      let selectedItem = this.dropDownList.filter(
        x => x.SurveySelecteeId == event.source.value
      )[0];
      if (selectedItem) this.selectedValues.push(selectedItem);
    }
    this.emitSelectedValues.emit(this.selectedValues);
  }

  openedChange(e) {
    this.openAddSelecteeTab = false;
    this.openFilterTab = e;
    if (e == false) {
      this.filter = new SelecteeFilter();
      this.addSelectee = new SelecteeFilter();
      this.emitSelectedValues.emit(this.selectedValues);
    }
    this.filteredOptions = this.dropDownList;
  }

  // Clearing search textbox value
  clearSearch(event) {
    this.filter = new SelecteeFilter();
    this.pageNum = 0;
    this.searchSelectee();
  }

  //  Set selected values to retain the
  setSelectedValues() {
    if (this.selectedValues && this.selectedValues.length >= 0) {
      let selectedItem = [];
      this.selectedValues.forEach(item => {
        selectedItem.push(item.SurveySelecteeId);
      });
      this.selectFormControl.setValue(selectedItem);
    }
  }

  searchSelectee(pageNum?: number) {
    pageNum || pageNum == 0 ? (this.pageNum = pageNum) : false;
    let isTranslated: boolean;
    if (this.dropDownList[0].Language) {
      isTranslated = true;
    }
    this.filter.FirstName
      ? (this.filter.LastName = this.filter.FirstName)
      : false;
    this.filter.skip =
      this.pageNum > 0 ? this.pageNum * this.pageSize : 0 * this.pageSize;
    this.filter.limit = this.pageSize;
    this.pageNum += 1;
    this.surveyDetailService
      .getSelecteeList(this.surveyId, this.filter)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          this.isSelecteeComplete =
            res.Data && res.Data.length == 0 ? true : false;
          if (res.Data && res.Data.Selectee && res.Data.Selectee.length > 0) {
            this.filteredOptions =
              pageNum == 0
                ? res.Data.Selectee
                : this.filteredOptions.concat(res.Data.Selectee);
          } else {
            this.filteredOptions = [];
          }
          this.setSelectedValues();
        } else {
        }
      });
  }

  saveSelectee(event) {
    this.saveNewValue.emit(this.addSelectee);
  }
}
