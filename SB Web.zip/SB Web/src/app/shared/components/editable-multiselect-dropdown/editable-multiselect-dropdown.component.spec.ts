import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditableMultiselectDropdownComponent } from './editable-multiselect-dropdown.component';

describe('EditableMultiselectDropdownComponent', () => {
  let component: EditableMultiselectDropdownComponent;
  let fixture: ComponentFixture<EditableMultiselectDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditableMultiselectDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditableMultiselectDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
