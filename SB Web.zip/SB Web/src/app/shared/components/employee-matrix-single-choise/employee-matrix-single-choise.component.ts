import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { SelectAutocompleteComponent } from 'mat-select-autocomplete';
import { SurveyDetailService } from 'src/app/pages/survey/survey-detail/survey-detail.service';
import { CommonService } from 'src/app/core/services/common.service';
import { SurveySelectee, FilterObject } from 'src/app/pages/survey/survey-detail/selectees/selectees.model';
import { UtilityComponent } from 'src/app/core/services/utility';
import { EditableMultiselectDropdownComponent } from '../editable-multiselect-dropdown/editable-multiselect-dropdown.component';

@Component({
  selector: 'app-employee-matrix-single-choise',
  templateUrl: './employee-matrix-single-choise.component.html',
  styleUrls: ['./employee-matrix-single-choise.component.scss']
})
export class EmployeeMatrixSingleChoiseComponent implements OnInit {
  @ViewChild(SelectAutocompleteComponent, { static: false }) multiSelect: SelectAutocompleteComponent;
  @ViewChild(EditableMultiselectDropdownComponent, { static: false }) editableDropdown: EditableMultiselectDropdownComponent;
  @Input() surveyId: number;
  @Input() question: any;

  constructor(private surveyDetailService: SurveyDetailService,
    private commonService: CommonService) { }
  displayedColumns: string[] = ['option', 'Name'];
  employees: any[] = [];
  public dataSource: any[] = [];
  public copyDataSource: any[] = [];
  public isLoadedEmployee: boolean;
  public surveySelectee: SurveySelectee = new SurveySelectee();
  public filter: FilterObject = new FilterObject();

  ngOnInit() {
    this.getSelecteeList(this.surveyId);
  }

  getSelecteeList(surveyId) {
    this.filter.skip = 0;
    this.filter.limit = 100;
    this.surveyDetailService.getSelecteeList(surveyId, this.filter).subscribe((res: any) => {
      if (res.Status == 'success') {
        if (res.Data !== null || res.Data !== undefined) {
          if (res.Data.Selectee) {
            this.employees = res.Data.Selectee;
          }
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.isLoadedEmployee = true;
    });
  }


  Remove(id) {
    this.copyDataSource = [];
    this.copyDataSource = JSON.parse(JSON.stringify(this.dataSource));
    this.dataSource = [];
    let index = this.copyDataSource.findIndex(t => t.SurveySelecteeId === id);
    let obj = this.copyDataSource.find(t => t.SurveySelecteeId === id);
    if (index > -1) {
      this.copyDataSource.splice(index, 1);
    }
    this.dataSource = JSON.parse(JSON.stringify(this.copyDataSource));
    obj.selected = false;
    obj.callFromParent = true;
    this.editableDropdown.selectionChange(obj);
  }

  receiveSelectedValues(employee) {
    this.dataSource = [];
    this.dataSource = JSON.parse(JSON.stringify(employee));
  }

  saveNewValue(data) {
    let Obj = {
      FirstName: data.FirstName,
      LastName: '',
      Email: data.Email,
      Role: data.Role,
      Department: data.Department,
      Miscellaneous: data.Miscellaneous,
      SurveyId: this.surveyId,
      Selected: false,
      EmployeeId: 0,
      SurveySelecteeId: 0,
      CompanyId: 0
    };
    this.surveySelectee = new SurveySelectee();
    this.surveySelectee.Selectee = [];
    this.surveySelectee.Selectee.push(Obj);
    this.surveySelectee.SurveyId = this.surveyId;
    this.surveySelectee.LastImportedDate = UtilityComponent.getUTCDate(new Date());
    this.surveyDetailService.saveSelectees(this.surveySelectee).subscribe((res: any) => {
      if (res.Status == 'success') {
        this.commonService.toaster(res.Message, true);
        let obj = [];
        obj = res.Data[0];
        this.employees.push(obj[0]);
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }
}
