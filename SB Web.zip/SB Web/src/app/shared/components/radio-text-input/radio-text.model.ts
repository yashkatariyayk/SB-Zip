export class RadioTextModel {
    Id: number;
    value: string;
    comment: boolean;
    commentRequired: boolean;
}
