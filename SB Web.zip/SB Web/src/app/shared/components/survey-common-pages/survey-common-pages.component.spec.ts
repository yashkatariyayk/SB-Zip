import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyCommonPagesComponent } from './survey-common-pages.component';

describe('SurveyCommonPagesComponent', () => {
  let component: SurveyCommonPagesComponent;
  let fixture: ComponentFixture<SurveyCommonPagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveyCommonPagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyCommonPagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
