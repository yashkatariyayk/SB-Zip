import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouteConfig } from 'src/app/route.config';
import { AuthService } from 'src/app/core/services/auth.service';
import { HttpClientService } from 'src/app/core/services/http-client.service';


@Injectable()
export class AddPageService {
    constructor(private http: HttpClient,
        private routeConfig: RouteConfig,
        private httpClient: HttpClientService,
        private auth: AuthService) { }


    getAllScaleType() {
        let url = '/survey/question/scaleType';
        return this.httpClient.get(url);
    }

    updatePage(page: any) {
        let url = '/survey/page';
        return this.httpClient.put(url, page);
    }

    removePage(id, PageOrder) {
        let url = '/survey/page?id=' + id + '&PageOrder=' + PageOrder;
        return this.httpClient.delete(url);
    }

    getQuestionByPage(surveyId, surveyPageId) {
        let url = '/survey/page?SurveyId=' + surveyId + '&SurveyPageId=' + surveyPageId;
        return this.httpClient.get(url);
    }

}
