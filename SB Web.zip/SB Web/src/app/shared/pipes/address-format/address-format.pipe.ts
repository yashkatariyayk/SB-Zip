import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'address',
  pure: true
})
export class AddressFormatPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let address = [];
    value[args.Address1] ? address.push(value[args.Address1]) : false;
    value[args.Address2] ? address.push(value[args.Address2]) : false;
    value[args.CityName] ? address.push(value[args.CityName]) : false;
    value[args.StateName] ? address.push(value[args.StateName]) : false;
    value[args.ZIP] ? address.push(value[args.ZIP]) : false;
    value[args.CountryName] ? address.push(value[args.CountryName]) : false;

    return address.length > 0 ? address.join(', ') : 'Address Not Available';
  }

}
