import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressFormatPipe } from './address-format.pipe';

@NgModule({
  imports: [
    CommonModule, FormsModule, RouterModule,
  ],
  declarations: [
    AddressFormatPipe
  ],
  exports: [
    AddressFormatPipe
  ],
})
export class AddressFormatModule { }
