import { Pipe, PipeTransform } from '@angular/core';

export interface IArrayFilter {
  value?: string;
  isSortable?: boolean;
  sortField?: string;
  filterField?: string;
}

@Pipe({
  name: 'arrayFilter',
  pure: false
})
export class ArrayFilterPipe implements PipeTransform {

  transform(items: any[], data: IArrayFilter): any {
    if (!items || !data.value) {
      return items;
    }

    let returnItems: any[] = [];
    !data.filterField ? data.filterField = 'InfoCode' : false;

    let valueFields = data.value.split(',');

    valueFields.forEach(value => {
      let returnItem = items.filter(x => (x[data.filterField]).toLowerCase() == value.toLowerCase());
      returnItem.forEach(itm => {
        returnItems.push(itm);
      });
    });

    if (data.isSortable) {
      returnItems = returnItems.sort((a, b) => a[data.sortField] ? a[data.sortField].toString().localeCompare(b[data.sortField].toString()) : false);
    }

    return returnItems;
  }
}
