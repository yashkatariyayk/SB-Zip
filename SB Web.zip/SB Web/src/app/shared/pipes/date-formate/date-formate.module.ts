import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateFormatePipe } from './date-formate.pipe';
import { SurveyModule } from 'src/app/pages/survey/survey.module';

@NgModule({
  imports: [
    CommonModule, FormsModule, RouterModule
  ],
  declarations: [
  //  DateFormatePipe
  ],
  exports : [
  //  DateFormatePipe
  ],
})
export class DateFormateModule { }
