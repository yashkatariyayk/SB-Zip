export class Recaptcha {
    secret: string;
    response: string;
    remoteip: string;
}

export interface AddressArgs {
    Address1?: string;
    Address2?: string;
    CityName?: string;
    StateName?: string;
    ZIP?: string;
    CountryName?: string;
    StreetNumber?: string;
    StreetName?: string;
}