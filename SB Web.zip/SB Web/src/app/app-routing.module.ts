import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./core/services/auth-guard.service";
import { DashboardLayoutComponent } from "./layout/dashboard-layout/dashboard-layout.component";

const routes: Routes = [
  // { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: "", redirectTo: "survey", pathMatch: "full" },
  // No layout routes : start
  { path: "login", loadChildren: "./pages/login/login.module#LoginModule" },
  {
    path: "",
    loadChildren: "./pages/login/login.module#LoginModule",
    pathMatch: "full"
  },
  {
    path: "preview/:id",
    loadChildren:
      "./pages/preview-survey/preview-survey.module#PreviewSurveyModule",
    pathMatch: "full"
  },
  // No layout routes : End

  // User Dashboard layout : Start
  {
    path: "",
    component: DashboardLayoutComponent,
    children: [
      // {
      //     path: 'dashboard',
      //     loadChildren: './pages/dashboard/dashboard.module#DashboardModule',
      //     // canActivate: [AuthGuard],
      //     data: {}
      // },
      {
        path: "create-survey",
        loadChildren:
          "./pages/create-survey/create-survey.module#CreateSurveyModule",
        canActivate: [AuthGuard],
        data: {}
      },
      {
        path: "survey",
        loadChildren: "./pages/survey/survey.module#SurveyModule",
        canActivate: [AuthGuard],
        data: {}
      },
      {
        path: "clients",
        loadChildren: "./pages/clients/clients.module#ClientsModule",
        canActivate: [AuthGuard],
        data: {}
      },
      {
        path: "email-library",
        loadChildren:
          "./pages/email-library/email-library.module#EmailLibraryModule",
        canActivate: [AuthGuard],
        data: {}
      },
      {
        path: "language",
        loadChildren: "./pages/language/language.module#LanguageModule",
        canActivate: [AuthGuard],
        data: {}
      },
      {
        path: "email-server",
        loadChildren:
          "./pages/email-server/email-server.module#EmailServerModule",
        canActivate: [AuthGuard],
        data: {}
      }
    ]
  },
  // User Dashboard layout : End

  // otherwise redirect to Login
  { path: "**", redirectTo: "login" }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { scrollPositionRestoration: "enabled" })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
